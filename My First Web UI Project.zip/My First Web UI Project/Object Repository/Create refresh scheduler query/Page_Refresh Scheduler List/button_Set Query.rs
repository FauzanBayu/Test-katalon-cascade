<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Set Query</name>
   <tag></tag>
   <elementGuidId>e9a168b8-32db-4357-9c53-aaeffe8439dc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>4aa15a73-2e19-43fe-9143-1bc785ba9844</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-outlined size-standart</value>
      <webElementGuid>f4fa0707-c34f-4c09-9887-ae999eafc80b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Set Query </value>
      <webElementGuid>4835fd2d-d91c-4f7f-82c6-9e46b6b1bb37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-query-scheduler[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/tbody[1]/tr[@class=&quot;mat-row cdk-row cursor-pointer-f ng-star-inserted&quot;]/td[@class=&quot;mat-cell cdk-cell cdk-column-action mat-column-action ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/button[@class=&quot;btn-global type-outlined size-standart&quot;]</value>
      <webElementGuid>168d0d9c-963d-48a8-858c-b227dca1fed4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit'])[1]/following::button[1]</value>
      <webElementGuid>1f133fd6-7a95-4a15-a0ab-fb3258d71670</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Active'])[1]/following::button[2]</value>
      <webElementGuid>4afa6ca0-d494-42c0-b25d-03bc5c6771a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='sample'])[1]/preceding::button[1]</value>
      <webElementGuid>57743710-c2ca-4f98-bf4d-bd7eb50b9849</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='once'])[1]/preceding::button[1]</value>
      <webElementGuid>5cb98ce8-8305-4349-8326-5ac5f49647c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Set Query']/parent::*</value>
      <webElementGuid>ffaa4cd8-f372-4300-a123-4ae173a37240</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[8]/div/button[2]</value>
      <webElementGuid>f7be69a7-1cea-4bf4-b07e-450ef3976a7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Set Query ' or . = ' Set Query ')]</value>
      <webElementGuid>ac2e2620-e86a-48d6-a3c1-95b820a153ac</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
