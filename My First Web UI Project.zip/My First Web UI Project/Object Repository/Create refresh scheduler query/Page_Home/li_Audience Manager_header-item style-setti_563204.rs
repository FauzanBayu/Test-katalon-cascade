<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Audience Manager_header-item style-setti_563204</name>
   <tag></tag>
   <elementGuidId>7cbbaf2f-3a98-4927-b4fc-78b2d4fb28ef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.header-item.style-setting.header-desktop.header-item-hover.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>d25dcedd-0882-4ae4-8c8d-4b7e06e19bc9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-item style-setting header-desktop header-item-hover ng-star-inserted</value>
      <webElementGuid>3721561c-ad95-4249-90e7-f6ebddf2933d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/li[@class=&quot;header-item style-setting header-desktop header-item-hover ng-star-inserted&quot;]</value>
      <webElementGuid>15bb9f10-221a-4b9e-8644-4127c46ad630</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      <webElementGuid>63b2d0b3-0546-41be-8730-e3b25f69a57d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::li[1]</value>
      <webElementGuid>85c5a0da-66d3-49b8-9055-88c042e713b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='F'])[1]/preceding::li[4]</value>
      <webElementGuid>f893a54d-cdc0-488f-ae58-6b9a2f9ce6f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan'])[1]/preceding::li[4]</value>
      <webElementGuid>121f2733-34bf-43d0-8a11-b802d762111d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li</value>
      <webElementGuid>1b0ebd6a-7ad5-48c4-ab3a-5eda9931a401</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
