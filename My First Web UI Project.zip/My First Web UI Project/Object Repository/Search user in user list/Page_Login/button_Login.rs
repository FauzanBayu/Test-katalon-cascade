<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Login</name>
   <tag></tag>
   <elementGuidId>18aeaf3c-69c4-4767-9995-a47eae48f968</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-for-login.btn-login-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot ?'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>35c0d179-1ff7-48f7-8e98-57fbe6745d6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-for-login btn-login-margin</value>
      <webElementGuid>868c0aeb-be83-4b69-b21c-ce29c1786177</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Login </value>
      <webElementGuid>d03f28bb-1821-4837-bd4a-fa3d3bd27b08</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;background-login light&quot;]/div[@class=&quot;right-login&quot;]/div[@class=&quot;login-section ng-star-inserted&quot;]/div[@class=&quot;form-login&quot;]/form[@class=&quot;ng-dirty ng-touched ng-valid&quot;]/button[@class=&quot;btn-global type-contained size-for-login btn-login-margin&quot;]</value>
      <webElementGuid>9eb8ae18-107f-497e-b395-a2ea55cdd484</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot ?'])[1]/following::button[1]</value>
      <webElementGuid>5cec5389-35ee-476c-bd9b-00f1fd5ee0a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::button[2]</value>
      <webElementGuid>0fcf3d77-b75f-48a5-8d41-460397a83927</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='powered by'])[2]/preceding::button[1]</value>
      <webElementGuid>7a8cb8ce-192e-430a-bb66-9ab9185cf31f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/button</value>
      <webElementGuid>c5d75fb6-a1b4-49c2-8c16-a535404f41ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Login ' or . = ' Login ')]</value>
      <webElementGuid>4c5f42b9-17c0-4552-8b89-0567a39a3405</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
