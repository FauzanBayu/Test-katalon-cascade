<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Last Activity_fi icon-down-dir icon-list</name>
   <tag></tag>
   <elementGuidId>5a0839c0-af80-45ee-953b-d32fc9face53</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.column-align-center > div.sort-wrapper > span.fi.icon-down-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d24d137f-0ae5-459a-9ea8-c104d918d468</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-down-dir icon-list</value>
      <webElementGuid>df82853f-1266-4f35-9e13-cc83e69726d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/ng-component[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;userlist-container body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row height-auto ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell width-200px-f cursor-pointer-f cdk-column-activity mat-column-activity ng-star-inserted&quot;]/span[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-down-dir icon-list&quot;]</value>
      <webElementGuid>9ba2c199-2721-433a-904b-09b7b5d206b2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/div/span[2]</value>
      <webElementGuid>807bdfb0-a634-484e-9e74-5d45dcde66c1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
