<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Status_fi icon-down-dir icon-list</name>
   <tag></tag>
   <elementGuidId>019b1a71-4dd8-4b1b-8138-b829cf2c97f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.cursor-pointer-f.cdk-column-status.mat-column-status.ng-star-inserted > span.column-align-center > div.sort-wrapper > span.fi.icon-down-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[5]/span/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>40bc1cd7-3299-4b6f-b8fc-4b4c83055ec8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-down-dir icon-list</value>
      <webElementGuid>1095d9b4-b9a2-4efb-94a1-12cd21f86304</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/ng-component[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;userlist-container body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row height-auto ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell cursor-pointer-f cdk-column-status mat-column-status ng-star-inserted&quot;]/span[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-down-dir icon-list&quot;]</value>
      <webElementGuid>28d19366-6ef9-4625-8384-791f839e2145</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[5]/span/div/span[2]</value>
      <webElementGuid>a3e5d882-135f-47c8-bbdd-14dff16b9c28</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
