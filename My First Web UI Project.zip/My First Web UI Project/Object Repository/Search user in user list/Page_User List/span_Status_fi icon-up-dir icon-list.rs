<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Status_fi icon-up-dir icon-list</name>
   <tag></tag>
   <elementGuidId>051b387a-be7b-4bae-b427-d29d596a9237</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.cursor-pointer-f.cdk-column-status.mat-column-status.ng-star-inserted > span.column-align-center > div.sort-wrapper > span.fi.icon-up-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[5]/span/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ab475247-b60c-4813-bbf6-d68f58f6f2e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-up-dir icon-list</value>
      <webElementGuid>077cadda-e245-4ce2-9d88-b1c48b6712cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/ng-component[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;userlist-container body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row height-auto ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell cursor-pointer-f cdk-column-status mat-column-status ng-star-inserted&quot;]/span[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-up-dir icon-list&quot;]</value>
      <webElementGuid>7672a95c-082a-4d67-bfa4-0bd622e209ed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[5]/span/div/span</value>
      <webElementGuid>4189a16d-210e-4b1f-bc14-84d6fc76b2e3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
