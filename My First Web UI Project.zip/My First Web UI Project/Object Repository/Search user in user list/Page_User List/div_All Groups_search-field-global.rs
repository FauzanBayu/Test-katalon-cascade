<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_All Groups_search-field-global</name>
   <tag></tag>
   <elementGuidId>7ea9b1c2-e509-4f8b-a789-22d9e8a0769b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.search-field-global</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='All Groups'])[1]/following::div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>5fdf7068-b788-4cc3-ae65-25d55d753ce7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>search-field-global</value>
      <webElementGuid>7aa38d01-6cd9-4135-83a1-885c8c6a6df2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/ng-component[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;userlist-container body-content set-bgcolor-querylist&quot;]/div[@class=&quot;userlist-header-table&quot;]/div[@class=&quot;userlist-header-table-left&quot;]/div[@class=&quot;search-field-global&quot;]</value>
      <webElementGuid>921c09a0-fb4c-446b-ac48-a3642e98f500</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Groups'])[1]/following::div[3]</value>
      <webElementGuid>fc532480-48f9-418b-8295-528d5ddaf846</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Users'])[1]/following::div[10]</value>
      <webElementGuid>f32ee631-44f8-4784-a393-ac503840a54e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create User'])[1]/preceding::div[1]</value>
      <webElementGuid>f6277f6d-13aa-4b20-bb13-bd61a9eb0bb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Username'])[1]/preceding::div[2]</value>
      <webElementGuid>49d1cba4-040c-4e5d-9d25-62a902aca053</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[2]</value>
      <webElementGuid>a27de13e-72db-464a-b4f1-c091ae3f4601</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
