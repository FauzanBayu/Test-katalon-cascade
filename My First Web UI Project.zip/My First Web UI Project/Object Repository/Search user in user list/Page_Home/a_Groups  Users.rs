<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Groups  Users</name>
   <tag></tag>
   <elementGuidId>1fea744d-310d-48ad-824d-1944b2e9b3a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.item-setting.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Groups &amp; Users')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c665e269-fe68-42d3-a009-8961d684bce5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/casc2nd/user/group-list</value>
      <webElementGuid>be56157e-bdbe-4e2e-8356-94ca6ee8e624</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-setting ng-star-inserted</value>
      <webElementGuid>7d7fefb5-af8e-48f6-9c17-6bd6588392ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Groups &amp; Users</value>
      <webElementGuid>4b1fc363-311f-44a0-931f-becf8e3b829a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/ul[@class=&quot;setting-dropdown header-desktop ng-star-inserted&quot;]/a[@class=&quot;item-setting ng-star-inserted&quot;]</value>
      <webElementGuid>52c887e8-73d2-41cd-98ac-b92bfbc0befc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Groups &amp; Users')]</value>
      <webElementGuid>47f15d2d-54c6-4d91-b34a-24461f6075b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::a[1]</value>
      <webElementGuid>63b70384-ee15-4e58-84f4-4115278b64ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::a[1]</value>
      <webElementGuid>2504dd35-d095-460e-be9b-e2f0a3f9a011</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quota Management'])[1]/preceding::a[1]</value>
      <webElementGuid>9ee688b4-a67c-43f8-a89a-8b90219a475f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Request'])[1]/preceding::a[2]</value>
      <webElementGuid>facb483f-b38f-4b2d-b37c-b4ff229c00e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Groups &amp; Users']/parent::*</value>
      <webElementGuid>cf56df29-a121-43c9-ab50-e66026503e4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/casc2nd/user/group-list')]</value>
      <webElementGuid>2af604e0-dda2-43fa-835b-5608ee1e970a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul/a</value>
      <webElementGuid>fd4c6e78-6127-423d-855d-3b904e5c6b06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/casc2nd/user/group-list' and (text() = ' Groups &amp; Users' or . = ' Groups &amp; Users')]</value>
      <webElementGuid>c5dec3a0-b2eb-492a-9c6d-e66221685d19</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
