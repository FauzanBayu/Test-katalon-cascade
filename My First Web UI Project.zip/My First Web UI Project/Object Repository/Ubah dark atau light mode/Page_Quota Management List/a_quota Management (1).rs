<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_quota Management (1)</name>
   <tag></tag>
   <elementGuidId>62c51857-5783-4e86-9f40-31c58ed6876e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'quota Management')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d8445698-353d-48fb-b776-f74e74eb6f5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>breadcrumb-name on-hover ng-star-inserted</value>
      <webElementGuid>4ffe3476-61be-4484-97e7-d1f87430b251</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/casc2nd/sync/quotaManagement</value>
      <webElementGuid>9bffeca5-0700-457b-bb91-f32820d45f22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>quota Management</value>
      <webElementGuid>544ac795-cb57-43c4-8b7f-325787b61430</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-managequota[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/div[@class=&quot;top-breadcrumb&quot;]/app-breadcrumb[1]/ul[@class=&quot;breadcrumb-body&quot;]/li[@class=&quot;breadcrumb-list ng-star-inserted&quot;]/a[@class=&quot;breadcrumb-name on-hover ng-star-inserted&quot;]</value>
      <webElementGuid>3105e372-d73f-472a-b09d-42560f301fe8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'quota Management')]</value>
      <webElementGuid>5c6895b5-f17e-4041-afe2-74290d1f1eb6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>'])[3]/following::a[1]</value>
      <webElementGuid>3a930742-7244-4fad-8df7-9af61f317c7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='sync'])[1]/following::a[1]</value>
      <webElementGuid>d788bdd2-ad28-470d-b68f-dd2ba14ba88f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>'])[4]/preceding::a[1]</value>
      <webElementGuid>5e13821f-e2da-42bb-82d6-6b95f3dd3fe5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='manage Quota'])[1]/preceding::a[1]</value>
      <webElementGuid>a0eba97e-edcc-4960-8bc0-0bdc7fc08efd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='quota Management']/parent::*</value>
      <webElementGuid>960423d8-bb46-4067-9aaa-302f9efab1c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/casc2nd/sync/quotaManagement')]</value>
      <webElementGuid>8c840c5c-9a96-4b06-b8b9-9711ca318865</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[7]/a</value>
      <webElementGuid>ff461034-553e-446f-a5f3-b8f06e44a201</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/casc2nd/sync/quotaManagement' and (text() = 'quota Management' or . = 'quota Management')]</value>
      <webElementGuid>a640ac6d-11e5-4634-b137-ac6f66de97ba</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
