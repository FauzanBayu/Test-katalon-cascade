<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Quota Management</name>
   <tag></tag>
   <elementGuidId>803b09cf-91ea-466f-adbb-7d1531792d41</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Quota Management')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a3bc8793-3c9b-4b4a-b679-03a5dea9d701</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/casc2nd/sync/quotaManagement</value>
      <webElementGuid>f8542a0b-ae85-4f16-b395-becdaaac1ef1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-setting ng-star-inserted</value>
      <webElementGuid>cc60902c-d6f4-4923-bd13-2821fd0a559e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Quota Management</value>
      <webElementGuid>591d70b9-e916-4cbc-9139-90a33176ecae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/ul[@class=&quot;setting-dropdown header-desktop ng-star-inserted&quot;]/a[@class=&quot;item-setting ng-star-inserted&quot;]</value>
      <webElementGuid>be474391-c21a-4d90-9836-0cb39bbb8f1d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Quota Management')]</value>
      <webElementGuid>67f1f77a-7823-4aa9-8898-6f6d8abfe684</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Groups &amp; Users'])[1]/following::a[1]</value>
      <webElementGuid>dda5a11f-8e0e-4ebc-8e16-480ea8ecac67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::a[2]</value>
      <webElementGuid>bab981b5-3e94-471f-a600-c8a84ba1db13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Request'])[1]/preceding::a[1]</value>
      <webElementGuid>f9b3986e-04cf-4ec7-a467-e3b625f72c44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refresh Scheduler'])[1]/preceding::a[2]</value>
      <webElementGuid>02b9c9b9-51e6-411e-b1ea-763ba3cd2abd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Quota Management']/parent::*</value>
      <webElementGuid>66015552-7d13-43b2-a678-4bcf0f357ae0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/casc2nd/sync/quotaManagement')]</value>
      <webElementGuid>19c3dc89-8abf-4b3c-8014-1b25df55d33a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul/a[2]</value>
      <webElementGuid>e7a6e33c-b932-4a6a-b117-4b9c74e874e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/casc2nd/sync/quotaManagement' and (text() = ' Quota Management' or . = ' Quota Management')]</value>
      <webElementGuid>bfcb4a78-4b47-45b3-ae8f-6db2af31f32d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
