<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_YOU ARE HEREhomesyncquota Management Qu_9cd2ed</name>
   <tag></tag>
   <elementGuidId>fd2dfe82-cc16-49fb-9aac-25fbafb0adf5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.body-content</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Back to Homepage'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>140ecdda-2a8d-4295-81c3-6b689e8bc700</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>body-content</value>
      <webElementGuid>44c3cc61-57d7-4d70-9d0b-36a47e130e5b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>YOU ARE HERE>home>sync>quota Management Quota Management User NameGroup AssignedRemaining QuotaActiondwiuser49.000 Transaction History  Manage Quota usertaufik40 Transaction History  Manage Quota 1</value>
      <webElementGuid>13921371-111e-45d6-bc3b-519d98178cf5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-quotemanagement[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]</value>
      <webElementGuid>f8011de5-0259-4a1b-b323-8e05ff2007ce</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Back to Homepage'])[1]/following::div[1]</value>
      <webElementGuid>96414343-4e74-4748-9be6-18c8c317a8d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We recommend to open this pageon desktop view'])[1]/following::div[1]</value>
      <webElementGuid>1ae148a9-849a-4ff1-924a-ccfd4a96fe31</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//app-quotemanagement/div</value>
      <webElementGuid>35ab77d9-4871-4961-9ad3-b3af643ba733</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'YOU ARE HERE>home>sync>quota Management Quota Management User NameGroup AssignedRemaining QuotaActiondwiuser49.000 Transaction History  Manage Quota usertaufik40 Transaction History  Manage Quota 1' or . = 'YOU ARE HERE>home>sync>quota Management Quota Management User NameGroup AssignedRemaining QuotaActiondwiuser49.000 Transaction History  Manage Quota usertaufik40 Transaction History  Manage Quota 1')]</value>
      <webElementGuid>d2efc256-0e42-43f0-ba4a-41f2701977f9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
