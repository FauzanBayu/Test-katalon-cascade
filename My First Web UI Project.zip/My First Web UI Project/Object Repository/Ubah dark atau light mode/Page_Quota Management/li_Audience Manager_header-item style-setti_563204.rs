<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Audience Manager_header-item style-setti_563204</name>
   <tag></tag>
   <elementGuidId>2f10c805-54db-4eff-a582-758d3865c499</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.header-item.style-setting.header-desktop.header-item-hover.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>edbb5d3a-986a-4512-bfe1-42cf97f1c8a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-item style-setting header-desktop header-item-hover ng-star-inserted</value>
      <webElementGuid>e636fa3e-4960-4977-8295-22a12f3a19f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/li[@class=&quot;header-item style-setting header-desktop header-item-hover ng-star-inserted&quot;]</value>
      <webElementGuid>b5626830-0f26-40d8-8ba9-4108c7262ba7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      <webElementGuid>e5e4e942-e1d3-494d-b0f4-0282ce4938b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::li[1]</value>
      <webElementGuid>73f69810-6466-4015-a666-594222ad7b0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='F'])[1]/preceding::li[4]</value>
      <webElementGuid>417c0032-1425-4483-808a-61bdbf4d5db8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan'])[1]/preceding::li[4]</value>
      <webElementGuid>1a9b8aa8-7709-4b25-bf2c-9c8d43734b80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li</value>
      <webElementGuid>1df38f46-e93b-493d-bbf8-0016306b8ef5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
