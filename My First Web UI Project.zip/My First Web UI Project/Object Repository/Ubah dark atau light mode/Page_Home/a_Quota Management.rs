<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Quota Management</name>
   <tag></tag>
   <elementGuidId>f29638b0-4a79-44cb-bf9f-ff2bf2d5e45b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Quota Management')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>84178486-d38d-4f52-b01c-74bea51fce56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/casc2nd/sync/quotaManagement</value>
      <webElementGuid>22412b13-e9ad-4194-968c-c6921e89151a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-setting ng-star-inserted</value>
      <webElementGuid>010f1fcd-df0a-40a1-8a6a-cc8bf86a9819</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Quota Management</value>
      <webElementGuid>1e4789b5-0b2e-41ae-b37b-b16c80b042ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/ul[@class=&quot;setting-dropdown header-desktop ng-star-inserted&quot;]/a[@class=&quot;item-setting ng-star-inserted&quot;]</value>
      <webElementGuid>aa6ec445-9ad3-4045-9170-38ef0f0ba443</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Quota Management')]</value>
      <webElementGuid>18ec325d-bb1f-4dd4-bd56-a9506fc04434</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Groups &amp; Users'])[1]/following::a[1]</value>
      <webElementGuid>d984555a-ee6e-4c71-8146-65616ee02e06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::a[2]</value>
      <webElementGuid>50c7cd57-406d-4d45-b0d9-e321fc5f5d67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Request'])[1]/preceding::a[1]</value>
      <webElementGuid>a3c333df-d360-45cf-a680-618d0535f3a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refresh Scheduler'])[1]/preceding::a[2]</value>
      <webElementGuid>c769617b-27e5-402c-870e-d531cf6fd5cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Quota Management']/parent::*</value>
      <webElementGuid>fecc3e14-1ad1-464a-910a-53f546a8f71b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/casc2nd/sync/quotaManagement')]</value>
      <webElementGuid>8e015f95-46cf-4daa-87e6-22f92c841596</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul/a[2]</value>
      <webElementGuid>a2b239e1-6741-45a5-a0a9-cee00d2f3088</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/casc2nd/sync/quotaManagement' and (text() = ' Quota Management' or . = ' Quota Management')]</value>
      <webElementGuid>484a5f70-95fe-41c9-a354-e690652478ad</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
