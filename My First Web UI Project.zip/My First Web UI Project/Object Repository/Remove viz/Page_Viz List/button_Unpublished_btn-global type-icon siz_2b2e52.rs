<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Unpublished_btn-global type-icon siz_2b2e52</name>
   <tag></tag>
   <elementGuidId>dff85a21-0ff7-42c1-ba35-de7e732b8f4f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-icon.size-large.style-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>8a3981d9-4ff4-4d2f-8665-ab1b885bdf66</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-icon size-large style-2</value>
      <webElementGuid>6dbb27d8-57e3-46bb-88bc-5f2c6710c7e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/tbody[1]/tr[@class=&quot;mat-row cdk-row cursor-pointer-f ng-star-inserted&quot;]/td[@class=&quot;mat-cell cdk-cell cdk-column-more mat-column-more ng-star-inserted&quot;]/div[@class=&quot;column-align-center position-relative-f ng-star-inserted&quot;]/button[@class=&quot;btn-global type-icon size-large style-2&quot;]</value>
      <webElementGuid>b9ff42a7-33b5-4014-8e06-ca0df1783fb8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[1]/following::button[1]</value>
      <webElementGuid>1a14b86b-54e5-4397-9ab1-7b0ee27c9894</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan.firrdaus@salt.com'])[2]/following::button[1]</value>
      <webElementGuid>30e70ece-222e-4f79-bec6-942aa0bbb562</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='katalon 2'])[1]/preceding::button[1]</value>
      <webElementGuid>54d41810-37d4-4ea0-8064-84fee541252b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz ID: 204'])[1]/preceding::button[1]</value>
      <webElementGuid>951beaf8-5921-408f-9666-5b410bc5d9df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[7]/div/button</value>
      <webElementGuid>46f4acbc-2a64-4104-9b1d-1635d4f98d99</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
