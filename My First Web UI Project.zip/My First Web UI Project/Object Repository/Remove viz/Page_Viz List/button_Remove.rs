<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Remove</name>
   <tag></tag>
   <elementGuidId>2488dc21-314a-4aba-83e5-30753926d97d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-standart.float-right-f.margin-left-20px-f</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Published'])[2]/following::button[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>df1f4b84-8918-4a9b-b0bf-5498a160925d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-standart float-right-f margin-left-20px-f</value>
      <webElementGuid>fe99dc86-4a6b-4fe7-8e29-8d2fefbff23d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Remove </value>
      <webElementGuid>4b2c89be-95ba-4ee2-8b0a-5733af9b9ddb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/div[@class=&quot;querylist-footer-table margin-top-20px-f&quot;]/div[@class=&quot;querylist-header-table-right ng-star-inserted&quot;]/button[@class=&quot;btn-global type-contained size-standart float-right-f margin-left-20px-f&quot;]</value>
      <webElementGuid>c906e43f-2a62-4175-b229-d12f6a620302</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Published'])[2]/following::button[4]</value>
      <webElementGuid>04790f89-101f-4eae-9cc7-0696065b5f56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan.firrdaus@salt.com'])[8]/following::button[4]</value>
      <webElementGuid>cb00aef4-4415-4cae-b91c-63773207ce12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/preceding::button[1]</value>
      <webElementGuid>eaabdd45-2d0f-4a99-ac10-e1ee8d98d054</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='WMS help you to generate image tiles from geospatial data. WMS can only use Kinetica datasource.'])[1]/preceding::button[2]</value>
      <webElementGuid>6a6f87f0-4beb-4c65-b2a3-9e7c17e0efbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Remove']/parent::*</value>
      <webElementGuid>2dcbfc35-ce10-4bca-b0c3-2ce7e6bb2051</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/button</value>
      <webElementGuid>463b7e3b-37ab-4223-b108-28eba12ad446</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Remove ' or . = ' Remove ')]</value>
      <webElementGuid>6b80f070-09bb-4388-b826-c31c51de0cf3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
