<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Action_mat-checkbox-inner-container ma_99aa3b</name>
   <tag></tag>
   <elementGuidId>99106640-147c-4cfd-bc9d-f4676b238905</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mat-checkbox-13 > label.mat-checkbox-layout > span.mat-checkbox-inner-container.mat-checkbox-inner-container-no-side-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-checkbox[@id='mat-checkbox-13']/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>172e9b4b-d98c-43a5-8122-7336b05c791b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin</value>
      <webElementGuid>31a75d66-c389-4da4-bb31-c179e992d26d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-checkbox-13&quot;)/label[@class=&quot;mat-checkbox-layout&quot;]/span[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;]</value>
      <webElementGuid>11b7030a-f75b-49be-9663-d62820e9cd6e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-checkbox[@id='mat-checkbox-13']/label/span</value>
      <webElementGuid>d5d5a63e-bd21-43de-9050-cfd5bd38db6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/following::span[1]</value>
      <webElementGuid>63e8115f-e7fb-4e74-aa13-705037280266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[1]/following::span[4]</value>
      <webElementGuid>7c0efaef-4a67-4dda-ba78-2acfcf09ef75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='viz katalon - copy'])[1]/preceding::span[8]</value>
      <webElementGuid>b6824fc9-a7d3-41f4-bc7f-4185baea778b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz ID: 207'])[1]/preceding::span[9]</value>
      <webElementGuid>9fc198dd-055c-46a2-8d59-50c7f640c5b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/mat-checkbox/label/span</value>
      <webElementGuid>5ecb8ca8-31a1-4527-be98-99e5a2e7b944</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
