<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_PublishCloneDelete Completely</name>
   <tag></tag>
   <elementGuidId>75eb527b-3fcb-4520-98b1-6831be8078fe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.more-outer.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c28bbdb2-dc53-4cd2-9b73-1f85a8adb83b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>more-outer ng-star-inserted</value>
      <webElementGuid>1f1bd5a7-2976-4f68-946e-29bc3193457c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>PublishCloneDelete Completely</value>
      <webElementGuid>b7f3dfdf-f0ed-4891-8cd9-96175a28b019</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/tbody[1]/tr[@class=&quot;mat-row cdk-row cursor-pointer-f ng-star-inserted&quot;]/td[@class=&quot;mat-cell cdk-cell cdk-column-more mat-column-more ng-star-inserted&quot;]/div[@class=&quot;column-align-center position-relative-f ng-star-inserted&quot;]/div[@class=&quot;more-outer ng-star-inserted&quot;]</value>
      <webElementGuid>4b4516de-056f-4b5d-8995-65f8cb0c3c6c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[1]/following::div[2]</value>
      <webElementGuid>daa80fd1-8727-494d-9f92-661a1d7cbf31</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan.firrdaus@salt.com'])[2]/following::div[3]</value>
      <webElementGuid>2971a98a-1a75-4369-902b-db94d83b08cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[7]/div/div</value>
      <webElementGuid>d457c14e-32ec-48ea-9268-805ab01c54ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'PublishCloneDelete Completely' or . = 'PublishCloneDelete Completely')]</value>
      <webElementGuid>d6a69669-ed28-4479-9a5d-b4da2718b914</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
