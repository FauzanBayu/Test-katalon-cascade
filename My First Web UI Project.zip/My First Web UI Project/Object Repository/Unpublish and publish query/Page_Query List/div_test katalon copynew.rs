<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_test katalon copynew</name>
   <tag></tag>
   <elementGuidId>ad4db109-95d0-4529-b510-634c44185442</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.overflow-ellipsis</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2f84b417-bb32-40b0-9f6f-42aa1cf133c0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>overflow-ellipsis</value>
      <webElementGuid>c15a0fc3-b5c0-4533-9192-b9658badc9fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>test katalon copynew</value>
      <webElementGuid>836c7696-d1cb-4278-8933-2435116009a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/tbody[1]/tr[@class=&quot;mat-row cdk-row cursor-pointer-f ng-star-inserted&quot;]/td[@class=&quot;mat-cell cdk-cell cdk-column-name mat-column-name ng-star-inserted&quot;]/a[1]/div[1]/span[@class=&quot;text-standard overflow-ellipsis width-200px-f display-flex-f align-items-center-f&quot;]/div[@class=&quot;overflow-ellipsis&quot;]</value>
      <webElementGuid>869cf757-3b2b-40a9-aac6-c8b68692ee52</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/following::div[2]</value>
      <webElementGuid>11c532e5-9efe-4375-8c46-c3d387ae7cd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Refresh'])[1]/following::div[2]</value>
      <webElementGuid>ece8b80e-e073-430a-9600-50c326005fbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Query ID: 805'])[1]/preceding::div[1]</value>
      <webElementGuid>00f01097-71e6-4f13-b9b2-56ce84c9ad30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='operational'])[1]/preceding::div[1]</value>
      <webElementGuid>cf738a65-f7c8-4102-8d75-c4f44b0f84ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='test katalon copynew']/parent::*</value>
      <webElementGuid>72b7a1b3-965c-4548-adec-2f0b1ab91f3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/span/div</value>
      <webElementGuid>ea6adc8a-87f2-45f6-985e-6700e2bfc6f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'test katalon copynew' or . = 'test katalon copynew')]</value>
      <webElementGuid>f1f16230-000a-4b38-86fa-ba98b4beb24b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
