<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Select Group</name>
   <tag></tag>
   <elementGuidId>4a8b9fbf-5b62-4a6e-a119-e76bd56df02b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>app-dropdown-custom.first-dropdown.sticky > div.section-dropdown-custom > div.container-dropdown-custom.ng-star-inserted > div.head-dropdown-custom.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id=''])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c875a6ac-94e9-4a0f-a868-224ce9f1021b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>head-dropdown-custom ng-star-inserted</value>
      <webElementGuid>ff309c94-be87-4202-8057-99e470c18b13</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Group</value>
      <webElementGuid>f86c3252-536f-475b-a601-53c77a2a9209</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-dialog-0&quot;)/app-clone-query[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;box-modal&quot;]/mat-dialog-content[@class=&quot;mat-dialog-content confirm-content dialog-new-component new-dashboard-page&quot;]/div[@class=&quot;dropdown-wrapper set-20px&quot;]/app-dropdown-custom[@class=&quot;first-dropdown sticky&quot;]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]</value>
      <webElementGuid>94f60ac1-da10-4b56-a6b9-07d4758c4a97</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//div[@id=''])[3]</value>
      <webElementGuid>b641117d-8898-4fa3-8604-2cc8b9d455cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-dialog-container[@id='mat-dialog-0']/app-clone-query/div/mat-dialog-content/div/app-dropdown-custom/div/div/div</value>
      <webElementGuid>398fd36d-d057-4187-9b8a-147bf66d996e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clone Query'])[1]/following::div[4]</value>
      <webElementGuid>d0ee480e-b7f4-43cd-8802-0c079b371ba4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='-'])[15]/following::div[16]</value>
      <webElementGuid>d6e7f6a0-bbaa-4f03-87cd-01130e60f872</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Datasource'])[1]/preceding::div[4]</value>
      <webElementGuid>e6a493ec-2800-4214-8941-3118e84aca9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-dialog-content/div/app-dropdown-custom/div/div/div</value>
      <webElementGuid>9c9d51d0-7ac1-4624-bbfa-d04fcd1b77b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Select Group' or . = 'Select Group')]</value>
      <webElementGuid>fd983b0f-d289-4ad1-9041-bb35dfb41108</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
