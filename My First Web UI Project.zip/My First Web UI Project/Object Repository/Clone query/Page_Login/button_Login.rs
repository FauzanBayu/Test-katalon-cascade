<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Login</name>
   <tag></tag>
   <elementGuidId>d12a9d99-c1c5-4aec-9f58-c9f1f0c3831d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-for-login.btn-login-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot ?'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>147d3b74-a27b-4475-9257-d23ca84fcb75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-for-login btn-login-margin</value>
      <webElementGuid>c4134026-68d4-49a5-bdba-dd527dbc7933</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Login </value>
      <webElementGuid>98b54d8a-0806-4876-8cd5-0d1d61274d1c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;background-login light&quot;]/div[@class=&quot;right-login&quot;]/div[@class=&quot;login-section ng-star-inserted&quot;]/div[@class=&quot;form-login&quot;]/form[@class=&quot;ng-dirty ng-touched ng-valid&quot;]/button[@class=&quot;btn-global type-contained size-for-login btn-login-margin&quot;]</value>
      <webElementGuid>38536796-11c8-4bcd-a686-0d339f410eda</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot ?'])[1]/following::button[1]</value>
      <webElementGuid>edc9ee16-1abf-4239-92e6-585f69552b54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::button[2]</value>
      <webElementGuid>2ca7ba20-040b-4020-892d-6a284ef5ee13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='powered by'])[2]/preceding::button[1]</value>
      <webElementGuid>af01d5a3-9732-4571-aa00-e247e7da6b7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/button</value>
      <webElementGuid>0a2d5f1e-4bc8-4b49-9367-bdbc34f0d5f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Login ' or . = ' Login ')]</value>
      <webElementGuid>230a03f1-ff7f-46e2-b474-e4cb5681c311</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
