<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Unpublished_btn-global type-icon siz_2b2e52</name>
   <tag></tag>
   <elementGuidId>571a54d2-e08d-458f-b9e1-82acaba83a8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[2]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>9303ecb7-1e59-4079-b56f-25914b6d8349</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-icon size-large style-2</value>
      <webElementGuid>37c104ca-4cce-450f-8598-7eae63c198a5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/tbody[1]/tr[@class=&quot;mat-row cdk-row cursor-pointer-f ng-star-inserted&quot;]/td[@class=&quot;mat-cell cdk-cell cdk-column-more mat-column-more ng-star-inserted&quot;]/div[@class=&quot;column-align-center position-relative-f ng-star-inserted&quot;]/button[@class=&quot;btn-global type-icon size-large style-2&quot;]</value>
      <webElementGuid>fc25ce32-5d52-455e-8012-c4f7a50d8ad1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[2]/following::button[1]</value>
      <webElementGuid>f823fc90-aafb-4f3e-b0ed-3c83016204bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan.firrdaus@salt.com'])[4]/following::button[1]</value>
      <webElementGuid>8f59a971-9b93-422d-a486-1f6690341442</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='adit ya'])[1]/preceding::button[1]</value>
      <webElementGuid>950d116e-fc0a-4592-9684-0a711f9d45db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz ID: 200'])[1]/preceding::button[1]</value>
      <webElementGuid>affbc459-21d3-49b2-ae42-f4a53d96cfa1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[7]/div/button</value>
      <webElementGuid>e5167850-c68b-4660-a558-88a8bc658b8e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
