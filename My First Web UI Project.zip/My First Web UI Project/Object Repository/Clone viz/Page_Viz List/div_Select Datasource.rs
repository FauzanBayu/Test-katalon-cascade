<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Select Datasource</name>
   <tag></tag>
   <elementGuidId>e6e89316-3162-4902-8dd3-a4a75d5aba72</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>mat-dialog-content.mat-dialog-content.confirm-content.dialog-new-component.new-dashboard-page > app-dropdown-custom.sticky > div.section-dropdown-custom > div.container-dropdown-custom.ng-star-inserted > div.head-dropdown-custom.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id=''])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>37721c57-45b9-4f17-8063-f979632212c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>head-dropdown-custom ng-star-inserted</value>
      <webElementGuid>4f5af890-e160-4d32-9f97-c9ff561d9874</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Datasource</value>
      <webElementGuid>ffa4a319-3db4-4d18-ab72-c43a5995a40e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-dialog-0&quot;)/app-dashboard-clone[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;box-modal&quot;]/mat-dialog-content[@class=&quot;mat-dialog-content confirm-content dialog-new-component new-dashboard-page&quot;]/app-dropdown-custom[@class=&quot;sticky&quot;]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]</value>
      <webElementGuid>b2696693-7ff0-4375-8471-9b99afde0100</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//div[@id=''])[3]</value>
      <webElementGuid>14fd3dd7-7dda-4b9d-af36-3c0829c223a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-dialog-container[@id='mat-dialog-0']/app-dashboard-clone/div/mat-dialog-content/app-dropdown-custom/div/div/div</value>
      <webElementGuid>058320eb-efc3-482c-a257-c2b84287bf73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='operational'])[5]/following::div[5]</value>
      <webElementGuid>37e06a65-abe2-4a69-b711-c8023d276edd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Group'])[1]/following::div[9]</value>
      <webElementGuid>29ab8476-5124-4a70-8998-805f9421d20a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clone'])[1]/preceding::div[4]</value>
      <webElementGuid>89b47c02-d9e7-465f-892e-756a76089b54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-dialog-content/app-dropdown-custom/div/div/div</value>
      <webElementGuid>72833572-3bed-41bb-9a0b-91c7e48a4d3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Select Datasource' or . = 'Select Datasource')]</value>
      <webElementGuid>790b4fef-75c9-49bf-82f4-633ddebb947e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
