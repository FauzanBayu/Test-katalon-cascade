<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Select Group</name>
   <tag></tag>
   <elementGuidId>6e69d0dd-691e-4de8-bc40-e4684e23641a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>app-dropdown-custom.first-dropdown.sticky > div.section-dropdown-custom > div.container-dropdown-custom.ng-star-inserted > div.head-dropdown-custom.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id=''])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3ea6baf8-902a-417a-b85f-f93683f9082e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>head-dropdown-custom ng-star-inserted</value>
      <webElementGuid>6490af6b-746f-4d04-ba96-93bb6f7d6139</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Group</value>
      <webElementGuid>2e161f54-40f7-4d76-8268-1d8ebfc5efd8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-dialog-0&quot;)/app-dashboard-clone[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;box-modal&quot;]/mat-dialog-content[@class=&quot;mat-dialog-content confirm-content dialog-new-component new-dashboard-page&quot;]/div[@class=&quot;search-box&quot;]/app-dropdown-custom[@class=&quot;first-dropdown sticky&quot;]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]</value>
      <webElementGuid>816453c4-cef6-464b-86ee-e8f2eca5d1b4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//div[@id=''])[2]</value>
      <webElementGuid>dc73ca8b-cfaf-44fd-82b6-02ec16335005</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-dialog-container[@id='mat-dialog-0']/app-dashboard-clone/div/mat-dialog-content/div[3]/app-dropdown-custom/div/div/div</value>
      <webElementGuid>7cfc614f-432f-4262-ac13-4139dcf5ce2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Group'])[1]/following::div[3]</value>
      <webElementGuid>aebf5b0e-88ef-45fa-b022-6c807c3662cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz Title'])[1]/following::div[4]</value>
      <webElementGuid>c575e819-e1fe-49bf-a8e7-b9375f56dfc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Datasource'])[1]/preceding::div[4]</value>
      <webElementGuid>84f36d46-f6f7-40af-b211-86548ce33f39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/app-dropdown-custom/div/div/div</value>
      <webElementGuid>ced9c0ad-a5ad-4828-87fb-2964a98820a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Select Group' or . = 'Select Group')]</value>
      <webElementGuid>059be26b-49a8-4750-a000-783c9c689262</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
