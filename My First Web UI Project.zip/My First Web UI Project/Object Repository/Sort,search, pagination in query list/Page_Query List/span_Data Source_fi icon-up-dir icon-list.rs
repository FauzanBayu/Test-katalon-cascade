<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Data Source_fi icon-up-dir icon-list</name>
   <tag></tag>
   <elementGuidId>9548c0b0-d20c-456f-b6a0-306803cc900b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.column-align-center > div.sort-wrapper > span.fi.icon-up-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[4]/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>eb435eae-05d7-4ad4-9b46-e956765e8321</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-up-dir icon-list</value>
      <webElementGuid>8c0c9a62-8d74-4e5a-b1e9-b6c07ed3f5f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell width-150px-f cursor-pointer-f cdk-column-dataSource-name mat-column-dataSource-name ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-up-dir icon-list&quot;]</value>
      <webElementGuid>a86ce71c-9c45-41bb-a329-7e855ae22df4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[4]/div/div/span</value>
      <webElementGuid>2670db66-5054-4f52-8de0-e382aabe6370</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
