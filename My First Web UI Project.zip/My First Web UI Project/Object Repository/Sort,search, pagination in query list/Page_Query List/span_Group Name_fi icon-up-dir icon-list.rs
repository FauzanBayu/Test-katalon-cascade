<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Group Name_fi icon-up-dir icon-list</name>
   <tag></tag>
   <elementGuidId>bf2ce1fd-10ca-4042-a654-6df03906c13c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.width-150px-f.cursor-pointer-f.cdk-column-group-name.mat-column-group-name.ng-star-inserted > span.column-align-center > div.sort-wrapper > span.fi.icon-up-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[3]/span/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a7c4a418-e3a8-4f06-a8fe-4317a0516144</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-up-dir icon-list</value>
      <webElementGuid>a87c04e8-43a4-4da2-a726-b12806600505</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell width-150px-f cursor-pointer-f cdk-column-group-name mat-column-group-name ng-star-inserted&quot;]/span[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-up-dir icon-list&quot;]</value>
      <webElementGuid>58ae36e0-1f07-49f5-9a8e-304001e1354d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[3]/span/div/span</value>
      <webElementGuid>8e81a81e-2cec-478a-987b-b29b672045ba</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
