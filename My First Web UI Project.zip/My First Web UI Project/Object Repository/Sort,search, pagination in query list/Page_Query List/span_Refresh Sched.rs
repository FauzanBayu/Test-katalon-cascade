<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Refresh Sched</name>
   <tag></tag>
   <elementGuidId>d5121511-e28f-4325-ae53-5bbb19dc74d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.cdk-column-refreshSched.mat-column-refreshSched.ng-star-inserted > div.column-align-center > span.text-header</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[1]/following::span[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d903e0c4-764c-47aa-8a88-83b3df336e2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-header</value>
      <webElementGuid>d7620b2f-b27c-405d-8c85-27b77f04b9c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Refresh Sched</value>
      <webElementGuid>080ac774-2bea-4a13-a716-45b66754f395</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell cdk-column-refreshSched mat-column-refreshSched ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/span[@class=&quot;text-header&quot;]</value>
      <webElementGuid>0ebc72c7-d5ab-4659-b3ee-6c700412d10e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[1]/following::span[3]</value>
      <webElementGuid>8d8ca483-6fb7-4ede-bbb6-efc9e5a40396</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Activity'])[1]/following::span[7]</value>
      <webElementGuid>a12b9d60-cc2a-49e0-b6ca-9a2570ebe2b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Refresh'])[1]/preceding::span[1]</value>
      <webElementGuid>62940764-bead-4247-9be5-7e08949fd935</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/preceding::span[2]</value>
      <webElementGuid>184112a6-939c-4bf5-83b2-07c5ecd3257a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Refresh Sched']/parent::*</value>
      <webElementGuid>3789bc2a-39d9-452d-a90e-8ab0c6460ffa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[7]/div/span</value>
      <webElementGuid>d1eedcff-c2cb-450c-8d3b-4b6046cf371c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Refresh Sched' or . = 'Refresh Sched')]</value>
      <webElementGuid>3f8e4db6-2638-44f5-964b-f2c71fff47c6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
