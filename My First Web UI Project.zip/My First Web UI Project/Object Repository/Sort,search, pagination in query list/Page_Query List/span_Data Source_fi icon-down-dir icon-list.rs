<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Data Source_fi icon-down-dir icon-list</name>
   <tag></tag>
   <elementGuidId>91a0cc07-4288-4bee-995b-8b3cf141e0f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.column-align-center > div.sort-wrapper > span.fi.icon-down-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7ddeab6c-f327-4768-956a-f90b862bdb4c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-down-dir icon-list</value>
      <webElementGuid>acc682ff-dae3-4149-97f0-b784f3fe74ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell width-150px-f cursor-pointer-f cdk-column-dataSource-name mat-column-dataSource-name ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-down-dir icon-list&quot;]</value>
      <webElementGuid>98cf8b22-4f38-489a-8bf0-662c9a7542cd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/span[2]</value>
      <webElementGuid>e66ff106-9cdd-4a79-9485-e79cfe87c099</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
