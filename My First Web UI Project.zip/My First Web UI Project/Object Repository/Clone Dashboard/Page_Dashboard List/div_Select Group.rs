<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Select Group</name>
   <tag></tag>
   <elementGuidId>3b2c810f-f158-4bc9-9307-2d1f19655522</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>app-dropdown-custom.sticky > div.section-dropdown-custom > div.container-dropdown-custom.ng-star-inserted > div.head-dropdown-custom.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id=''])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>142a72d9-6ee9-4db1-bca5-72d04837cfe5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>head-dropdown-custom ng-star-inserted</value>
      <webElementGuid>3bdb6a5c-e1cd-4540-9971-91d88b37209e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Group</value>
      <webElementGuid>82133593-727d-41d0-b93a-1582a9092158</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-dialog-0&quot;)/app-product-clone[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;box-modal&quot;]/mat-dialog-content[@class=&quot;mat-dialog-content confirm-content dialog-new-component new-dashboard-page&quot;]/div[@class=&quot;search-box&quot;]/app-dropdown-custom[@class=&quot;sticky&quot;]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]</value>
      <webElementGuid>9155bb3f-9299-427d-94c0-154b95a7fee3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//div[@id=''])[2]</value>
      <webElementGuid>33c49294-1ebc-4e0c-acab-d02d0bdc2362</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-dialog-container[@id='mat-dialog-0']/app-product-clone/div/mat-dialog-content/div[2]/app-dropdown-custom/div/div/div</value>
      <webElementGuid>7baf952a-7d01-4495-8180-77fb213d68f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Group'])[1]/following::div[3]</value>
      <webElementGuid>af7c6c62-3f3f-428f-bc9c-8f9e436562fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard Name'])[2]/following::div[4]</value>
      <webElementGuid>032d96be-97f4-4d95-9fa9-122edbd46df6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clone'])[1]/preceding::div[4]</value>
      <webElementGuid>3911006c-047c-44eb-8572-2d42c6e3945c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/app-dropdown-custom/div/div/div</value>
      <webElementGuid>29f4e4a0-34c5-43f4-91f3-5827d8702c08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Select Group' or . = 'Select Group')]</value>
      <webElementGuid>168bdd18-8e2c-4346-8248-b92bb7c5426f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
