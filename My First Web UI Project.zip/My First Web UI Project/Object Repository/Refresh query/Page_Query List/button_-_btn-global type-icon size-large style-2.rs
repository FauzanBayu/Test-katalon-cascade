<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_-_btn-global type-icon size-large style-2</name>
   <tag></tag>
   <elementGuidId>53699163-9b98-4eab-88a4-1310bc04f49b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-icon.size-large.style-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='-'])[3]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>0a22b58c-21af-413f-bab9-ba6f86306c8e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-icon size-large style-2</value>
      <webElementGuid>35d1ad60-8cc6-4b1b-b67f-f6535cbff2d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content set-bgcolor-querylist&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/tbody[1]/tr[@class=&quot;mat-row cdk-row cursor-pointer-f ng-star-inserted&quot;]/td[@class=&quot;mat-cell cdk-cell cdk-column-more mat-column-more ng-star-inserted&quot;]/div[@class=&quot;column-align-center position-relative-f ng-star-inserted&quot;]/button[@class=&quot;btn-global type-icon size-large style-2&quot;]</value>
      <webElementGuid>14c4657a-1397-40b6-b9bb-5c509a5ff41a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='-'])[3]/following::button[1]</value>
      <webElementGuid>e454c165-0f10-4975-848c-f5816fbcb914</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='-'])[2]/following::button[1]</value>
      <webElementGuid>85d51434-61d9-4518-96b6-20d5740e99fd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='[V-207] point'])[1]/preceding::button[1]</value>
      <webElementGuid>18ce48fa-8e73-4690-a3cb-1d1b8bf981f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Query ID: 808'])[1]/preceding::button[1]</value>
      <webElementGuid>ae510b3c-c6b9-4927-86ec-f71ed16a0693</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[9]/div/button</value>
      <webElementGuid>ccad46f1-2fdf-429d-8c53-a90a223d2d2d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
