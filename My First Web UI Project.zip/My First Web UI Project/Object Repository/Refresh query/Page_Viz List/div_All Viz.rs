<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_All Viz</name>
   <tag></tag>
   <elementGuidId>27dd9775-ed05-4ea9-add9-e8043f0d0c38</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text-allqueries</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='viz'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>302f162f-23d1-40a4-8339-745ecf4fc142</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-allqueries</value>
      <webElementGuid>b20e8895-6cb9-43ca-8436-f68553318fc6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> All Viz </value>
      <webElementGuid>b10e9378-c8f3-4170-82f4-07d501ad5204</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/div[@class=&quot;text-allqueries&quot;]</value>
      <webElementGuid>cd28ab24-8f67-4b13-9b79-8213640e1768</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='viz'])[1]/following::div[1]</value>
      <webElementGuid>ab797f67-8600-40a8-b37f-54d6a28c4217</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='>'])[2]/following::div[1]</value>
      <webElementGuid>b41bd52a-7124-4cea-a3a4-5c319257f14d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Groups'])[1]/preceding::div[1]</value>
      <webElementGuid>76d1e55b-a092-45b5-86e0-8f21621d6e62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Viz'])[1]/preceding::div[10]</value>
      <webElementGuid>0e54461b-3dea-4e82-a440-c3c445b3b2e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='All Viz']/parent::*</value>
      <webElementGuid>00890b6a-f6fb-4406-b562-6317098ce8e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//app-list/div/div[2]</value>
      <webElementGuid>4eb3022d-ca74-49ee-9906-fbf54bb077c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' All Viz ' or . = ' All Viz ')]</value>
      <webElementGuid>5ccc7817-de00-422a-80fb-bdc2c00dd19d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
