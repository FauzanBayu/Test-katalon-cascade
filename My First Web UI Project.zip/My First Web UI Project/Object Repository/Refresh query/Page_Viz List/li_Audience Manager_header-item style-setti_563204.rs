<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Audience Manager_header-item style-setti_563204</name>
   <tag></tag>
   <elementGuidId>4e3bc7f6-fcbf-4907-93c0-eedc9739d517</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.header-item.style-setting.header-desktop.header-item-hover.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>375a29ce-dbc2-488a-be39-78b6cb7feb0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-item style-setting header-desktop header-item-hover ng-star-inserted</value>
      <webElementGuid>d3316c6f-9930-4918-892b-1539f3d1f1dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/li[@class=&quot;header-item style-setting header-desktop header-item-hover ng-star-inserted&quot;]</value>
      <webElementGuid>0c038b7c-2a15-4abe-9d7a-8f6384de1368</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      <webElementGuid>c8d07875-e04b-4fea-a73b-305e680975d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::li[1]</value>
      <webElementGuid>716f9cc0-16c3-4d55-9b69-8f8455a656c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='F'])[1]/preceding::li[4]</value>
      <webElementGuid>48120c66-7877-445d-a2d4-bb54a8dd0bde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan'])[1]/preceding::li[4]</value>
      <webElementGuid>442e9996-1c46-4c26-8e6f-9a617182efd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li</value>
      <webElementGuid>4a3d6a99-4d5e-4eac-b128-304110d47142</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
