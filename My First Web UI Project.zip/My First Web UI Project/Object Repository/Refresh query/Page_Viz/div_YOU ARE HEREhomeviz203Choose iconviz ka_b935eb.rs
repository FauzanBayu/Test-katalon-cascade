<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_YOU ARE HEREhomeviz203Choose iconviz ka_b935eb</name>
   <tag></tag>
   <elementGuidId>72a24ce8-aeab-4a97-afcb-cbbdfd960143</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.viz-wrapper</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Back to Homepage'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>536a8b8a-e8c3-4451-893c-91d583057db9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>viz-wrapper</value>
      <webElementGuid>ea40b246-ca5e-4aca-9ee1-f2772927de02</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>YOU ARE HERE>home>viz>203Choose iconviz katalon Unpublished viz katalon.operational - localhost Updated Viz 18 hours ago Save as Draft Save &amp; Publish Filter Save Global Filter  Cross Filter Local FilterNo filter displayedPlease manage filterApplyReset800point798pointpointTo navigate, press the arrow keys.Keyboard shortcutsMap DataMap data ©2022Terms of UseReport a map errorMap data ©2022Data updated 11 days ago</value>
      <webElementGuid>98053d33-a233-448a-9303-615775edc819</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-visualization-showcase[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;viz-wrapper&quot;]</value>
      <webElementGuid>297eee77-38f8-41b3-8137-d7c3bd67ddf3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Back to Homepage'])[1]/following::div[1]</value>
      <webElementGuid>d0907b09-5cb2-4a08-9a03-4a1df4dd4986</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We recommend to open this pageon desktop view'])[1]/following::div[1]</value>
      <webElementGuid>09d10710-bc3f-4711-ab26-fa607c823eaa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//app-visualization-showcase/div</value>
      <webElementGuid>e672f092-d0a5-4397-8f34-190de59ae070</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'YOU ARE HERE>home>viz>203Choose iconviz katalon Unpublished viz katalon.operational - localhost Updated Viz 18 hours ago Save as Draft Save &amp; Publish Filter Save Global Filter  Cross Filter Local FilterNo filter displayedPlease manage filterApplyReset800point798pointpointTo navigate, press the arrow keys.Keyboard shortcutsMap DataMap data ©2022Terms of UseReport a map errorMap data ©2022Data updated 11 days ago' or . = 'YOU ARE HERE>home>viz>203Choose iconviz katalon Unpublished viz katalon.operational - localhost Updated Viz 18 hours ago Save as Draft Save &amp; Publish Filter Save Global Filter  Cross Filter Local FilterNo filter displayedPlease manage filterApplyReset800point798pointpointTo navigate, press the arrow keys.Keyboard shortcutsMap DataMap data ©2022Terms of UseReport a map errorMap data ©2022Data updated 11 days ago')]</value>
      <webElementGuid>547a914c-f90c-4444-8263-7506bc5c67af</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
