<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_CEMPAKA PUTIH</name>
   <tag></tag>
   <elementGuidId>68179583-4962-410c-8459-76b060f2a0ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div/div/div/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bd95d3bf-8569-4347-bd5f-6fb8a5ad3ee4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CEMPAKA PUTIH</value>
      <webElementGuid>fd3633a4-9a1c-4117-b1f9-68f9105e75d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;viz-detail-top-section-wrapper-id&quot;)/div[@class=&quot;header-section&quot;]/div[@class=&quot;button-area&quot;]/div[@class=&quot;content-wrapper&quot;]/div[@class=&quot;global-filter-viz-wrap&quot;]/app-global-filter[@class=&quot;ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;global-filter-wrap ng-tns-c195-4&quot;]/div[@class=&quot;filter-panel ng-tns-c195-4 ng-trigger ng-trigger-mobileGlobalFilter&quot;]/div[@class=&quot;panel-body ng-tns-c195-4 ng-trigger ng-trigger-dynamicPanelBodyHeight&quot;]/div[@class=&quot;global-filter-section ng-tns-c195-4&quot;]/div[@class=&quot;global-filter-content ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;core-filters ng-tns-c195-4&quot;]/div[@class=&quot;single-manage-filter-wrapper ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;ng-tns-c195-4 ng-star-inserted&quot;]/ng-multiselect-dropdown[@class=&quot;ng-multi-select-dash multiselect-dropdown-global ng-tns-c195-4 ng-untouched ng-valid ng-star-inserted ng-dirty&quot;]/div[@class=&quot;multiselect-dropdown&quot;]/div[@class=&quot;dropdown-list&quot;]/ul[@class=&quot;item2&quot;]/li[@class=&quot;multiselect-item-checkbox ng-star-inserted&quot;]/div[1]</value>
      <webElementGuid>d2197614-8a88-4f79-9ef3-142c82c297ca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div/div/div/div/ng-multiselect-dropdown/div/div[2]/ul[2]/li[2]/div</value>
      <webElementGuid>da980ae2-032a-4944-b396-93dd9623c610</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CAKUNG'])[1]/following::div[1]</value>
      <webElementGuid>1f00bce5-6117-410a-bd42-e114aed0d1bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select All'])[1]/following::div[2]</value>
      <webElementGuid>b62f9d25-fdd4-45d1-bcf2-4d1f7e417de7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CENGKARENG'])[1]/preceding::div[1]</value>
      <webElementGuid>d6309b1c-ed01-4e48-b1f1-cd8244fd4497</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CILANDAK'])[1]/preceding::div[2]</value>
      <webElementGuid>9c3430a4-6362-48e3-8b61-a5201c3b37a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='CEMPAKA PUTIH']/parent::*</value>
      <webElementGuid>a751b987-4659-4f9a-946e-6cf83f842abd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/div</value>
      <webElementGuid>701390b0-e278-4402-8c3f-b2af841c8266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'CEMPAKA PUTIH' or . = 'CEMPAKA PUTIH')]</value>
      <webElementGuid>3914f473-6f3d-4bed-88c6-bd51baac128b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
