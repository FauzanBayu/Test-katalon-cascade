<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Reset All Filters</name>
   <tag></tag>
   <elementGuidId>787c5a4d-dfe5-4494-88bf-7bb82e5db703</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.reset-button.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='viz-detail-top-section-wrapper-id']/div[2]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f9b4d8b4-bc10-47cb-98cb-90b64eea94ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>reset-button ng-star-inserted</value>
      <webElementGuid>819015eb-7a47-41a3-9a34-22133810899e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Reset All Filters </value>
      <webElementGuid>8fbd56ce-096c-4cfa-8db3-7ad714b30a2c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;viz-detail-top-section-wrapper-id&quot;)/div[@class=&quot;filter-info-section-viz&quot;]/div[@class=&quot;action-section&quot;]/div[@class=&quot;reset-button ng-star-inserted&quot;]</value>
      <webElementGuid>fc47a371-ae0f-46b3-978c-d8bf8c9e0b69</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='viz-detail-top-section-wrapper-id']/div[2]/div/div</value>
      <webElementGuid>25eab0c3-e4c8-43fe-8a4c-0ff843784bb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='kecamatan: CAKUNG'])[1]/following::div[3]</value>
      <webElementGuid>5478ee39-a2e3-4614-9112-bfc2d305191a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset'])[1]/following::div[10]</value>
      <webElementGuid>e258156e-0c78-45b6-b1e3-b0607743db7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply'])[2]/preceding::div[22]</value>
      <webElementGuid>41de1a6e-8851-4e25-b263-045714ede345</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset'])[2]/preceding::div[22]</value>
      <webElementGuid>22d818a5-a37a-431a-ae3b-fea2df3da217</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Reset All Filters']/parent::*</value>
      <webElementGuid>843c173a-de4a-41ae-9aaf-4bd4a10a70d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div</value>
      <webElementGuid>9e60a8fe-0937-4463-94d3-2fd41a6ed7bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' Reset All Filters ' or . = ' Reset All Filters ')]</value>
      <webElementGuid>40a632f5-0446-4c0a-a907-4ae9a226fbe5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
