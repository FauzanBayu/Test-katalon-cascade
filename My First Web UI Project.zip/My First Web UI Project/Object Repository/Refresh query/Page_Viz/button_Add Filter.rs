<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Add Filter</name>
   <tag></tag>
   <elementGuidId>651fd0b6-1a19-4217-9a66-86973ba6135c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.add-filter-wrapper.ng-tns-c195-4.ng-star-inserted > button.btn-global.type-contained.size-standart.ng-tns-c195-4</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div[2]/div/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>fcea988b-0e92-4510-83e6-1af265fb6ab2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-standart ng-tns-c195-4</value>
      <webElementGuid>ff4f9419-b99a-4ac6-8d41-bc820888f786</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add Filter</value>
      <webElementGuid>9ebb55ae-314e-4a41-8807-aecd224a495e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;viz-detail-top-section-wrapper-id&quot;)/div[@class=&quot;header-section&quot;]/div[@class=&quot;button-area&quot;]/div[@class=&quot;content-wrapper&quot;]/div[@class=&quot;global-filter-viz-wrap&quot;]/app-global-filter[@class=&quot;ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;global-filter-wrap ng-tns-c195-4&quot;]/div[@class=&quot;filter-panel ng-tns-c195-4 ng-trigger ng-trigger-mobileGlobalFilter&quot;]/div[@class=&quot;panel-body ng-tns-c195-4 ng-trigger ng-trigger-dynamicPanelBodyHeight&quot;]/div[@class=&quot;global-filter-section ng-tns-c195-4&quot;]/div[@class=&quot;global-filter-content ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;add-filter-wrapper ng-tns-c195-4 ng-star-inserted&quot;]/button[@class=&quot;btn-global type-contained size-standart ng-tns-c195-4&quot;]</value>
      <webElementGuid>f0fd8303-fa90-40b0-8234-819f1705fb4d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div[2]/div/button</value>
      <webElementGuid>7a274712-a797-46b6-8347-93c5152a4ec3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Global Filter'])[1]/following::button[1]</value>
      <webElementGuid>1e794849-84c7-4890-943d-0b3ae1ee4f2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/following::button[1]</value>
      <webElementGuid>086bfb41-240f-443a-a8c1-6cc6ecc95410</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cross Filter'])[1]/preceding::button[1]</value>
      <webElementGuid>da37797f-630c-4c20-a5cf-3ac6cea5e614</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply'])[1]/preceding::button[3]</value>
      <webElementGuid>07144f0f-775d-445d-ad1b-a3747dd2f18a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add Filter']/parent::*</value>
      <webElementGuid>e6ce0b9d-75b6-485b-bc94-08d6e3e841f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/button</value>
      <webElementGuid>95e3fcb5-1056-46d1-9621-d163fb4fea23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Add Filter' or . = 'Add Filter')]</value>
      <webElementGuid>789dd55c-8bd7-4e7b-b625-061b49f4b9cb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
