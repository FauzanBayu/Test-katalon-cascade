<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Global Filter</name>
   <tag></tag>
   <elementGuidId>5ac3e735-7a1a-43b4-b308-e2811618ef0d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.global-filter-accordion-title.ng-tns-c195-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>e72eeaec-39d3-4794-8fc1-b5fdab5a86d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>global-filter-accordion-title ng-tns-c195-2</value>
      <webElementGuid>012da5ad-7e7e-4a06-92e4-358a3a1af7bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Global Filter</value>
      <webElementGuid>7e699ccb-3932-4830-a1f0-3b51f591bee8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;viz-detail-top-section-wrapper-id&quot;)/div[@class=&quot;header-section&quot;]/div[@class=&quot;button-area&quot;]/div[@class=&quot;content-wrapper&quot;]/div[@class=&quot;global-filter-viz-wrap&quot;]/app-global-filter[@class=&quot;ng-tns-c195-2 ng-star-inserted&quot;]/div[@class=&quot;global-filter-wrap ng-tns-c195-2&quot;]/div[@class=&quot;filter-panel ng-tns-c195-2 ng-trigger ng-trigger-mobileGlobalFilter&quot;]/div[@class=&quot;panel-body ng-tns-c195-2 ng-trigger ng-trigger-dynamicPanelBodyHeight&quot;]/div[@class=&quot;global-filter-section ng-tns-c195-2&quot;]/div[@class=&quot;global-filter-accordion ng-tns-c195-2 ng-star-inserted&quot;]/h2[@class=&quot;global-filter-accordion-title ng-tns-c195-2&quot;]</value>
      <webElementGuid>811a6655-4de7-4448-b297-5e37e3b8f935</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div/h2</value>
      <webElementGuid>5d4c5f71-478a-42ce-bdd5-a904683f1b87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/following::h2[1]</value>
      <webElementGuid>83fa3b5c-ca02-47b9-baec-3277b7370706</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Filter'])[1]/following::h2[1]</value>
      <webElementGuid>83190cf4-d6a4-4da7-acd7-59df62ab0183</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cross Filter'])[1]/preceding::h2[1]</value>
      <webElementGuid>50e51613-ad41-4abe-8e07-62813f0705a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply'])[1]/preceding::h2[2]</value>
      <webElementGuid>992c1b4e-2a46-45b5-83d8-11ddb42808bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Global Filter']/parent::*</value>
      <webElementGuid>6450b70b-e26f-4bc7-af65-6e8bff2856d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>9be21743-bde2-4512-8554-7c864b5bf7e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Global Filter' or . = 'Global Filter')]</value>
      <webElementGuid>7b0d4e6a-6f26-4066-8b62-b7215109b4f2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
