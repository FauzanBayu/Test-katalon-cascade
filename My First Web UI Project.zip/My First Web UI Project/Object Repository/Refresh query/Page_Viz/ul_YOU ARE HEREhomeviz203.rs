<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_YOU ARE HEREhomeviz203</name>
   <tag></tag>
   <elementGuidId>844cb0fa-de7f-4071-9e84-feafe50cebb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.breadcrumb-body</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Back to Homepage'])[1]/following::ul[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>b7d9e2e4-2750-496b-89b3-5eeb4c576a35</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>breadcrumb-body</value>
      <webElementGuid>f49e9320-eac8-4224-9c5d-fefba0f709c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>YOU ARE HERE>home>viz>203</value>
      <webElementGuid>a9424cbb-d997-4bb5-b945-acb99560cabb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-visualization-showcase[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;viz-wrapper&quot;]/div[@class=&quot;viz-detail-top-breadcrumb&quot;]/app-breadcrumb[1]/ul[@class=&quot;breadcrumb-body&quot;]</value>
      <webElementGuid>dfd1f1be-f24a-4611-8155-8a6e9a1cdcff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Back to Homepage'])[1]/following::ul[1]</value>
      <webElementGuid>7f5b00eb-862e-458b-97f2-6577f4c18986</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We recommend to open this pageon desktop view'])[1]/following::ul[1]</value>
      <webElementGuid>09d463b7-2e8a-43d0-8e8c-7a8aff8a185c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//app-breadcrumb/ul</value>
      <webElementGuid>b55abc64-1918-4f75-90f8-32906a2241eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = 'YOU ARE HERE>home>viz>203' or . = 'YOU ARE HERE>home>viz>203')]</value>
      <webElementGuid>788b8b1d-a71a-4370-9fef-0c707ef3e7f3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
