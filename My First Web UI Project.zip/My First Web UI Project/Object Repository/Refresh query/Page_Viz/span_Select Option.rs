<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Select Option</name>
   <tag></tag>
   <elementGuidId>74e7fff1-9bd1-4e04-9819-b0744745f7ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.limitationChar.txt-place-holder > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div[2]/div[2]/div/div/div/app-dropdown-custom/div/div/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>42562e68-446e-4ccb-8ab9-481a4363be31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>31148624-15f6-47f3-b5a6-607e53142222</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Option</value>
      <webElementGuid>146f70c8-44d8-43d5-ab8f-768e2d138968</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;viz-detail-top-section-wrapper-id&quot;)/div[@class=&quot;header-section&quot;]/div[@class=&quot;button-area&quot;]/div[@class=&quot;content-wrapper&quot;]/div[@class=&quot;global-filter-viz-wrap&quot;]/app-global-filter[@class=&quot;ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;global-filter-wrap ng-tns-c195-4&quot;]/div[@class=&quot;filter-panel ng-tns-c195-4 ng-trigger ng-trigger-mobileGlobalFilter&quot;]/div[@class=&quot;panel-body ng-tns-c195-4 ng-trigger ng-trigger-dynamicPanelBodyHeight&quot;]/div[@class=&quot;global-filter-section ng-tns-c195-4&quot;]/div[@class=&quot;global-filter-content ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;core-filters ng-tns-c195-4&quot;]/div[@class=&quot;single-manage-filter-wrapper ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;single-manage-filter ng-tns-c195-4 ng-star-inserted&quot;]/div[@class=&quot;ng-tns-c195-4 ng-star-inserted&quot;]/app-dropdown-custom[@class=&quot;ng-tns-c195-4&quot;]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;limitationChar txt-place-holder&quot;]/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>136eda5d-de36-4e46-8050-96c856d315ab</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='viz-detail-top-section-wrapper-id']/div/div[3]/div/div[4]/app-global-filter/div/div[2]/div[2]/div/div[2]/div[2]/div/div/div/app-dropdown-custom/div/div/div/div/span</value>
      <webElementGuid>39f45cff-cf35-46a3-8598-47c8977e78f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add Filter'])[1]/following::span[2]</value>
      <webElementGuid>ef657430-63e9-495c-b000-67223946f59c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Global Filter'])[1]/following::span[3]</value>
      <webElementGuid>2b05c913-03de-47f6-912d-5dc8c94431cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cross Filter'])[1]/preceding::span[3]</value>
      <webElementGuid>6b91f1be-3698-4c21-9945-48aa3a289b7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Apply'])[1]/preceding::span[8]</value>
      <webElementGuid>809a80e4-d331-4e2d-bbb9-fd11375bf7bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Select Option']/parent::*</value>
      <webElementGuid>7801b88d-8e9b-4f18-8df6-910bc15ddfe5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//app-dropdown-custom/div/div/div/div/span</value>
      <webElementGuid>c84c4432-021c-4507-acd8-db3ced177fec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Select Option' or . = 'Select Option')]</value>
      <webElementGuid>02cf280b-cf57-4e64-a671-8fe52578a2bb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
