<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mat-drawer-content_FfauzanAdminDesktop View_0598b1</name>
   <tag></tag>
   <elementGuidId>e2f1cf13-9156-4d77-8dec-814d42715483</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>mat-drawer-content.mat-drawer-content.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::mat-drawer-content[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-drawer-content</value>
      <webElementGuid>55875816-ee7c-4fd6-9184-4f815ce886a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-drawer-content ng-star-inserted</value>
      <webElementGuid>e3487cf8-9a80-42d2-8349-5fb129c40b7b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>FfauzanAdminDesktop View OnlyWe recommend to open this pageon desktop viewBack to HomepageYOU ARE HERE>home>viz>204Choose iconkatalon 2 Unpublished katalon 2.operational - localhost Updated Viz 18 hours ago Save as Draft Save &amp; Publish FilterKecamatan CAKUNG x CEMPAKA PUTIH x CILANDAK x CENGKARENG x CILINCING x CIPAYUNG x CIRACAS x+5Select AllCAKUNGCEMPAKA PUTIHCENGKARENGCILANDAKCILINCINGCIPAYUNGCIRACASDUREN SAWITGAMBIRGROGOL PETAMBURANJAGAKARSAJATINEGARAJOHAR BARUKALI DERESKEBAYORAN BARUKEBAYORAN LAMAKEBON JERUKKELAPA GADINGKEMAYORANKEMBANGANKOJAKRAMAT JATIMAKASARMAMPANG PRAPATANMATRAMANMENTENGPADEMANGANPALMERAHPANCORANPASAR MINGGUPASAR REBOPENJARINGANPESANGGRAHANPULO GADUNGSAWAH BESARSENENSETIA BUDITAMAN SARITAMBORATANAH ABANGTANJUNG PRIOKTEBETApplyReset kecamatan: CAKUNG  6+  Reset All Filters Local FilterNo filter displayedPlease manage filterApplyReset800point798pointpointTo navigate, press the arrow keys.Keyboard shortcutsMap DataMap data ©2022Terms of UseReport a map errorMap data ©2022Data updated 11 days ago</value>
      <webElementGuid>547b3d10-2fde-4583-925f-1cef5b3d5298</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]</value>
      <webElementGuid>1056c553-3de6-4189-b785-6cae522df549</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::mat-drawer-content[1]</value>
      <webElementGuid>2fa57dc9-9722-470f-abde-16215e9712d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::mat-drawer-content[1]</value>
      <webElementGuid>18a584be-4022-486f-8e1f-130a7bcc1d92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-drawer-content</value>
      <webElementGuid>b33fc15b-49fb-424b-ae9b-5c41eba5f90f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//mat-drawer-content[(text() = 'FfauzanAdminDesktop View OnlyWe recommend to open this pageon desktop viewBack to HomepageYOU ARE HERE>home>viz>204Choose iconkatalon 2 Unpublished katalon 2.operational - localhost Updated Viz 18 hours ago Save as Draft Save &amp; Publish FilterKecamatan CAKUNG x CEMPAKA PUTIH x CILANDAK x CENGKARENG x CILINCING x CIPAYUNG x CIRACAS x+5Select AllCAKUNGCEMPAKA PUTIHCENGKARENGCILANDAKCILINCINGCIPAYUNGCIRACASDUREN SAWITGAMBIRGROGOL PETAMBURANJAGAKARSAJATINEGARAJOHAR BARUKALI DERESKEBAYORAN BARUKEBAYORAN LAMAKEBON JERUKKELAPA GADINGKEMAYORANKEMBANGANKOJAKRAMAT JATIMAKASARMAMPANG PRAPATANMATRAMANMENTENGPADEMANGANPALMERAHPANCORANPASAR MINGGUPASAR REBOPENJARINGANPESANGGRAHANPULO GADUNGSAWAH BESARSENENSETIA BUDITAMAN SARITAMBORATANAH ABANGTANJUNG PRIOKTEBETApplyReset kecamatan: CAKUNG  6+  Reset All Filters Local FilterNo filter displayedPlease manage filterApplyReset800point798pointpointTo navigate, press the arrow keys.Keyboard shortcutsMap DataMap data ©2022Terms of UseReport a map errorMap data ©2022Data updated 11 days ago' or . = 'FfauzanAdminDesktop View OnlyWe recommend to open this pageon desktop viewBack to HomepageYOU ARE HERE>home>viz>204Choose iconkatalon 2 Unpublished katalon 2.operational - localhost Updated Viz 18 hours ago Save as Draft Save &amp; Publish FilterKecamatan CAKUNG x CEMPAKA PUTIH x CILANDAK x CENGKARENG x CILINCING x CIPAYUNG x CIRACAS x+5Select AllCAKUNGCEMPAKA PUTIHCENGKARENGCILANDAKCILINCINGCIPAYUNGCIRACASDUREN SAWITGAMBIRGROGOL PETAMBURANJAGAKARSAJATINEGARAJOHAR BARUKALI DERESKEBAYORAN BARUKEBAYORAN LAMAKEBON JERUKKELAPA GADINGKEMAYORANKEMBANGANKOJAKRAMAT JATIMAKASARMAMPANG PRAPATANMATRAMANMENTENGPADEMANGANPALMERAHPANCORANPASAR MINGGUPASAR REBOPENJARINGANPESANGGRAHANPULO GADUNGSAWAH BESARSENENSETIA BUDITAMAN SARITAMBORATANAH ABANGTANJUNG PRIOKTEBETApplyReset kecamatan: CAKUNG  6+  Reset All Filters Local FilterNo filter displayedPlease manage filterApplyReset800point798pointpointTo navigate, press the arrow keys.Keyboard shortcutsMap DataMap data ©2022Terms of UseReport a map errorMap data ©2022Data updated 11 days ago')]</value>
      <webElementGuid>f30b136c-e568-44ff-85a1-028ebbceaa1c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
