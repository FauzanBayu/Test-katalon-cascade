<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Add to Viz</name>
   <tag></tag>
   <elementGuidId>f20d78d1-3cdd-48da-ad47-f99aefbebfb7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-standart.margin-right-10px-f</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>99f055b7-bb1c-43ed-9ed9-3842225ccd1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-standart margin-right-10px-f</value>
      <webElementGuid>47871bcb-2a1c-4acb-bd9d-7764fbd84dbb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Add to Viz </value>
      <webElementGuid>893b7dcd-472e-4a01-8397-bbbf2892a0d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-add-widget[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;dashboard-container body-content set-bgcolor-querylist&quot;]/div[2]/div[@class=&quot;filter-outer&quot;]/div[@class=&quot;align-self-center&quot;]/button[@class=&quot;btn-global type-contained size-standart margin-right-10px-f&quot;]</value>
      <webElementGuid>1aa40428-97fc-44ab-bf28-2a22c4579393</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::button[1]</value>
      <webElementGuid>fe423df8-30ef-4990-a397-c4b77b2439ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='point'])[1]/following::button[3]</value>
      <webElementGuid>d354e7dd-a407-4df4-8dab-3705ef3704d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='point'])[2]/preceding::button[1]</value>
      <webElementGuid>34229265-78cc-4836-a683-2ae1db00579d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='To navigate, press the arrow keys.'])[1]/preceding::button[2]</value>
      <webElementGuid>dd77386e-280d-4299-b6df-2bfbc712e843</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Add to Viz']/parent::*</value>
      <webElementGuid>a686fd4f-7452-4d3e-8206-89577cce6a83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/button[2]</value>
      <webElementGuid>6cf7de5d-16f4-4d6b-81ee-765655151027</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Add to Viz ' or . = ' Add to Viz ')]</value>
      <webElementGuid>c2c3453b-fe9a-4ad9-86cd-985e83686a4d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
