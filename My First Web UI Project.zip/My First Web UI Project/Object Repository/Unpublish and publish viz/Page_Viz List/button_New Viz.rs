<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_New Viz</name>
   <tag></tag>
   <elementGuidId>43b51ac9-244a-4482-ad96-b2991090fc70</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-labeled-icon.float-right-f.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='All Groups'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>9274e373-1ac7-461d-8692-0a55a34c8cb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-labeled-icon float-right-f ng-star-inserted</value>
      <webElementGuid>3efc4ac4-db94-4b06-b558-39539fc7c754</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New Viz </value>
      <webElementGuid>6ef1fb75-feb8-4dd1-8617-3a37eb85bbb7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/div[@class=&quot;querylist-header-table&quot;]/div[@class=&quot;querylist-header-table-right ng-star-inserted&quot;]/button[@class=&quot;btn-global type-contained size-labeled-icon float-right-f ng-star-inserted&quot;]</value>
      <webElementGuid>69da5c71-1688-427b-8ab9-7a9bd6a36e53</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Groups'])[1]/following::button[1]</value>
      <webElementGuid>582b1eb7-1549-4456-8bda-f27972001d91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Viz'])[1]/following::button[1]</value>
      <webElementGuid>c999bed9-2d33-4ac1-a2fa-3bae0637d161</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz Name'])[1]/preceding::button[1]</value>
      <webElementGuid>b789d860-8600-4b94-b646-3817a8a67a15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Group Name'])[1]/preceding::button[1]</value>
      <webElementGuid>a9d63f63-9cf0-478b-9fdd-455c026d25b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New Viz']/parent::*</value>
      <webElementGuid>eab709bb-3d22-45f8-9f7f-3d278cecb7f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/button</value>
      <webElementGuid>29f4b25c-cebd-4006-b6c2-1819276ab3ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'New Viz ' or . = 'New Viz ')]</value>
      <webElementGuid>9b3bf67a-bc2e-4968-83e4-5938da5868ca</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
