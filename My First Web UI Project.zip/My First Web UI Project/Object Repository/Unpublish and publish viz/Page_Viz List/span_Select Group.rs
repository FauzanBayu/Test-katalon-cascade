<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Select Group</name>
   <tag></tag>
   <elementGuidId>8b0f3db2-b040-46ca-ba55-ff858c7a5540</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.limitationChar.txt-place-holder > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-dialog-container[@id='mat-dialog-0']/app-newdashboard/div/mat-dialog-content/div[3]/app-dropdown-custom/div/div/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>50eb195c-1f14-421d-83d2-cff8ccad6089</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>b697e06a-91ee-4643-9be0-4fc3f658675f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Group</value>
      <webElementGuid>6775c31a-c13a-47f3-80ac-42d3c70679ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-dialog-0&quot;)/app-newdashboard[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;box-modal&quot;]/mat-dialog-content[@class=&quot;mat-dialog-content confirm-content dialog-new-component new-dashboard-page&quot;]/div[@class=&quot;search-box&quot;]/app-dropdown-custom[@class=&quot;sticky&quot;]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;limitationChar txt-place-holder&quot;]/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>dee320fe-76ff-403c-b6ae-c4324d1edf83</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-dialog-container[@id='mat-dialog-0']/app-newdashboard/div/mat-dialog-content/div[3]/app-dropdown-custom/div/div/div/div/span</value>
      <webElementGuid>5f6a6441-7ed6-4e7c-97ee-164e7b91d3fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Group'])[1]/following::span[1]</value>
      <webElementGuid>c583cf91-0fa5-4694-a567-bdc6e1e43a4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz Title'])[1]/following::span[1]</value>
      <webElementGuid>5e2f5e2a-3ab2-4fa9-aa10-796f70b570f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Source'])[2]/preceding::span[1]</value>
      <webElementGuid>8a07bd8f-8417-4d15-9b3b-75682bb84e29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Datasource'])[1]/preceding::span[1]</value>
      <webElementGuid>df46fdc3-f4a6-47f3-8f28-dce4fdd3549a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Select Group']/parent::*</value>
      <webElementGuid>9dc9f898-4ba4-428f-b920-6e6c08b8302b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/app-dropdown-custom/div/div/div/div/span</value>
      <webElementGuid>552f8209-6e3b-4809-86e7-fad46f8538a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Select Group' or . = 'Select Group')]</value>
      <webElementGuid>38148cc6-d72b-40d2-9b31-c93c53738f86</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
