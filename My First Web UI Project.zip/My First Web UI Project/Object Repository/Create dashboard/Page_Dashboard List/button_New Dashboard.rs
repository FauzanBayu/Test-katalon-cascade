<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_New Dashboard</name>
   <tag></tag>
   <elementGuidId>8d409d55-85ba-424b-9ed8-66d8ab0b3dfc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-labeled-icon.float-right-f.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='All Groups'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>93849956-e5be-4d3f-95fb-4f50f489fae1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-labeled-icon float-right-f ng-star-inserted</value>
      <webElementGuid>b6767fa9-a44b-4663-88c5-e5a553c64a0e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New Dashboard </value>
      <webElementGuid>d68453c6-e4d5-426e-a484-bec0fbd08777</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-product-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/div[@class=&quot;querylist-header-table&quot;]/div[@class=&quot;querylist-header-table-right ng-star-inserted&quot;]/button[@class=&quot;btn-global type-contained size-labeled-icon float-right-f ng-star-inserted&quot;]</value>
      <webElementGuid>e5426802-f90a-4d48-9648-b4b2a5e3cb5a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Groups'])[1]/following::button[1]</value>
      <webElementGuid>b83aebc7-86c2-425a-9a80-d3db0db591e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Dashboards'])[1]/following::button[1]</value>
      <webElementGuid>87139dc6-2da9-4949-8e48-6ac801513076</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard Name'])[1]/preceding::button[1]</value>
      <webElementGuid>c0510d25-8ebe-48bb-86e4-4c6e8e3d704c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Group Name'])[1]/preceding::button[1]</value>
      <webElementGuid>95cbbba9-cbf7-49fd-b736-f6369a0ed9ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New Dashboard']/parent::*</value>
      <webElementGuid>2a82c8dd-10ea-4383-abeb-73f1e5a089b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/button</value>
      <webElementGuid>c9497207-291d-4e1c-9320-f559c639982b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'New Dashboard ' or . = 'New Dashboard ')]</value>
      <webElementGuid>018c0da0-a4b2-48b9-8efa-2ddd0ce2a0d9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
