<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Select Data Source</name>
   <tag></tag>
   <elementGuidId>fe82670f-87ed-43a9-993c-66f308105940</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.limitationChar.txt-place-holder > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='query-source-component']/div/app-dropdown-custom/div/div/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4ca7ae95-d20d-4a07-9deb-1173a1f3aa98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>bca3f71a-8493-4bea-b8ef-e5aab2a0fbf6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Data Source</value>
      <webElementGuid>ef109fb8-5f1c-44f7-aed0-7cab4909d2d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;query-source-component&quot;)/div[@class=&quot;spacing-component ng-star-inserted&quot;]/app-dropdown-custom[1]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;limitationChar txt-place-holder&quot;]/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>83268a9a-7ea5-497f-b8bb-c7cefbc4d20f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='query-source-component']/div/app-dropdown-custom/div/div/div/div/span</value>
      <webElementGuid>a1c52ae8-dbff-466c-b2f0-64fb420632f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='operational'])[1]/following::span[1]</value>
      <webElementGuid>7ce40208-b4b4-4fa0-95ef-0b0a4ee455c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='test katalon'])[2]/following::span[4]</value>
      <webElementGuid>d6e37e15-ebee-4ca6-bf83-0e9c6905130e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[1]/preceding::span[1]</value>
      <webElementGuid>7c69a156-913e-4f47-ac2a-bde5495f477c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Select Data Source']/parent::*</value>
      <webElementGuid>0c5540b0-6a29-4732-8b55-39db38ced85d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/app-dropdown-custom/div/div/div/div/span</value>
      <webElementGuid>1603d48f-ff82-4311-a94b-7653e8692b4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Select Data Source' or . = 'Select Data Source')]</value>
      <webElementGuid>c139bd6e-c348-47cb-894f-e1d806e6885e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
