<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Click here to enter description</name>
   <tag></tag>
   <elementGuidId>aa32b247-b783-4f52-b930-dd6258cade05</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.can-edit.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='queryDescription']/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>5acc236e-3fe6-4186-b5ca-27a792c2cf2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>can-edit ng-star-inserted</value>
      <webElementGuid>e2276bef-1b32-40fb-a65b-38106af439fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Click here to enter description</value>
      <webElementGuid>600f4647-9dc9-41cc-9bcf-f6892ed2bd23</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;queryDescription&quot;)/h2[@class=&quot;can-edit ng-star-inserted&quot;]</value>
      <webElementGuid>34f0d68e-9de1-4e7c-bc4d-4baade3f9893</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='queryDescription']/h2</value>
      <webElementGuid>efc06271-0fbf-45b1-866d-0465ba2037db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General'])[2]/following::h2[1]</value>
      <webElementGuid>962fbdd1-5253-4a31-9313-fc25a6e73887</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[1]/following::h2[1]</value>
      <webElementGuid>253e39b8-c959-45fa-9202-0330b60b6b24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='operational'])[1]/preceding::h2[1]</value>
      <webElementGuid>2e0c4707-34fe-451c-9d3c-f498b280dea1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='localhost'])[1]/preceding::h2[1]</value>
      <webElementGuid>630d9da8-f465-4c64-8cea-0189b99f616b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Click here to enter description']/parent::*</value>
      <webElementGuid>5b5af2ed-2efc-442a-b6c0-415e32b40dba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>e8b79a53-50d6-4d1d-912b-316f44a4b367</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Click here to enter description' or . = 'Click here to enter description')]</value>
      <webElementGuid>8f8cdb14-4eaa-4cfd-811c-64b298a423a2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
