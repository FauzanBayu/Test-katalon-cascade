<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Select Group</name>
   <tag></tag>
   <elementGuidId>be91ce9c-41b7-4574-8cd8-f7776bfef8f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.limitationChar.txt-place-holder > span.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='query-source-component']/app-dropdown-custom/div/div/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>cfc224d1-31f2-4eb1-a834-9b0f60f8e5a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-star-inserted</value>
      <webElementGuid>b260b302-7820-4ad9-8b20-7878ccea00b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Group</value>
      <webElementGuid>fee7b481-e0e3-436d-80f4-736f05785b63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;query-source-component&quot;)/app-dropdown-custom[1]/div[@class=&quot;section-dropdown-custom&quot;]/div[@class=&quot;container-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;head-dropdown-custom ng-star-inserted&quot;]/div[@class=&quot;limitationChar txt-place-holder&quot;]/span[@class=&quot;ng-star-inserted&quot;]</value>
      <webElementGuid>94dfbf35-8099-4f2b-86ee-bc40cd2f4c5c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='query-source-component']/app-dropdown-custom/div/div/div/div/span</value>
      <webElementGuid>b53658c0-77f1-43f2-bafc-14bf62e66df6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click here to enter description'])[1]/following::span[3]</value>
      <webElementGuid>7812ba70-1aaa-4495-a8b2-2346210ef2b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='General'])[2]/following::span[3]</value>
      <webElementGuid>ce2dae44-868b-4cef-ad16-57ab3e1022a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[1]/preceding::span[1]</value>
      <webElementGuid>cde99f91-018c-475c-b3ba-10862469590a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Select Group']/parent::*</value>
      <webElementGuid>1f49dfa5-aed2-4485-9bba-c6959e2d31d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/span</value>
      <webElementGuid>81a987f0-5397-41f2-b713-58b436733c5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Select Group' or . = 'Select Group')]</value>
      <webElementGuid>0b50a224-8747-4127-a203-50014dd35124</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
