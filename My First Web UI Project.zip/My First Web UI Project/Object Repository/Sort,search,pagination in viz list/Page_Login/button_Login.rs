<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Login</name>
   <tag></tag>
   <elementGuidId>c5b51690-78dd-48d3-9fc2-df4e5ec55eac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-for-login.btn-login-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot ?'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>865a8228-e2fe-453e-aadf-c59810d0c5e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-for-login btn-login-margin</value>
      <webElementGuid>42d4df02-053e-44dc-8e4e-2754acce4e65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Login </value>
      <webElementGuid>d3867cf0-a5bb-4f2a-a5d8-30b18c8a358d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-login[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;background-login light&quot;]/div[@class=&quot;right-login&quot;]/div[@class=&quot;login-section ng-star-inserted&quot;]/div[@class=&quot;form-login&quot;]/form[@class=&quot;ng-dirty ng-touched ng-valid&quot;]/button[@class=&quot;btn-global type-contained size-for-login btn-login-margin&quot;]</value>
      <webElementGuid>228ec573-89db-43a4-ad73-03d8320bfeda</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot ?'])[1]/following::button[1]</value>
      <webElementGuid>ea045863-a04b-402e-8271-4665058f9851</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::button[2]</value>
      <webElementGuid>cf433c4a-f9cd-46a6-81d3-69b3e1104aae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='powered by'])[2]/preceding::button[1]</value>
      <webElementGuid>5c9678c4-c1a5-4e72-9b16-e8be9d26b954</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/button</value>
      <webElementGuid>d8998db2-1175-4a8b-a69b-959211b0c4c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Login ' or . = ' Login ')]</value>
      <webElementGuid>0e74bcf5-b299-46a1-8a2f-c1ebd077ae65</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
