<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Last Activity_fi icon-up-dir icon-list</name>
   <tag></tag>
   <elementGuidId>4cb180d4-5316-411b-9d6c-fef4b012b50c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.width-150px-f.cursor-pointer-f.cdk-column-updatedAt.mat-column-updatedAt.ng-star-inserted > div.column-align-center > div.sort-wrapper > span.fi.icon-up-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[5]/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e1912e3e-5eef-471b-ba7e-9ddc5a24cb44</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-up-dir icon-list</value>
      <webElementGuid>606da78d-47cd-4538-9cc6-1f204e1dc42d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell width-150px-f cursor-pointer-f cdk-column-updatedAt mat-column-updatedAt ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-up-dir icon-list&quot;]</value>
      <webElementGuid>1f4755c1-c510-4b97-9ba9-88596faa0c6c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[5]/div/div/span</value>
      <webElementGuid>9a6d24d4-0c03-4367-b549-93dab3a99d0c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
