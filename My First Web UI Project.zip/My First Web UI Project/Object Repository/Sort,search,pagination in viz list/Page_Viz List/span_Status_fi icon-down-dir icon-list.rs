<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Status_fi icon-down-dir icon-list</name>
   <tag></tag>
   <elementGuidId>a667c82e-6a13-4feb-8e05-0078f3739d6e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.cursor-pointer-f.cdk-column-isPublished.mat-column-isPublished.ng-star-inserted > div.column-align-center > div.sort-wrapper > span.fi.icon-down-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[6]/div/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f75bf2b5-3f38-41c4-8915-73fd122497db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-down-dir icon-list</value>
      <webElementGuid>cba2236f-e9d8-41f9-9127-acd21f6603a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell cursor-pointer-f cdk-column-isPublished mat-column-isPublished ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-down-dir icon-list&quot;]</value>
      <webElementGuid>17f5ebc0-4458-45ea-8d51-9b6c42888af9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[6]/div/div/span[2]</value>
      <webElementGuid>8d1bf839-9a2e-484d-8f58-7e044a77be51</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
