<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Status_fi icon-up-dir icon-list</name>
   <tag></tag>
   <elementGuidId>539676e8-9e45-4374-94a2-3816252e52b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.cursor-pointer-f.cdk-column-isPublished.mat-column-isPublished.ng-star-inserted > div.column-align-center > div.sort-wrapper > span.fi.icon-up-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[6]/div/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ab54e38c-6636-4642-b13a-79b9808d08a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-up-dir icon-list</value>
      <webElementGuid>46858c8c-3122-4203-bfa1-a32125b63f11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell cursor-pointer-f cdk-column-isPublished mat-column-isPublished ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-up-dir icon-list&quot;]</value>
      <webElementGuid>2070b097-d6dd-4918-963a-4141dbeed283</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[6]/div/div/span</value>
      <webElementGuid>9f6e39e6-e0a5-4062-bfda-f9c50f1c6f8b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
