<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Audience Manager_header-item style-setti_563204</name>
   <tag></tag>
   <elementGuidId>9e842f66-4ec4-4b1a-83b5-e6f689db9fa8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.header-item.style-setting.header-desktop.header-item-hover.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>10952a11-fb8b-4d63-9795-85575ecb5e79</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-item style-setting header-desktop header-item-hover ng-star-inserted</value>
      <webElementGuid>541e38dc-2017-4d0e-9fbc-750413859e20</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/li[@class=&quot;header-item style-setting header-desktop header-item-hover ng-star-inserted&quot;]</value>
      <webElementGuid>c0221473-adc9-40c8-a813-0784a775acf9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      <webElementGuid>3fc9ae61-d243-4e25-8c98-0f18cc97142c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::li[1]</value>
      <webElementGuid>0a89ab12-7fcc-44a4-bb91-c3502c428c5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='F'])[1]/preceding::li[4]</value>
      <webElementGuid>0f2cb487-b5be-432d-ae8d-0ff10ea45777</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan'])[1]/preceding::li[4]</value>
      <webElementGuid>b7d19306-b452-49ce-aca0-2ac493cd272d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li</value>
      <webElementGuid>8cdab384-c514-4885-9e32-d46e5d35b5e8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
