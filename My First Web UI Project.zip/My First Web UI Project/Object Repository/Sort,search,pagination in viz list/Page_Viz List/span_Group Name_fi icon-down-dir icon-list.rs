<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Group Name_fi icon-down-dir icon-list</name>
   <tag></tag>
   <elementGuidId>ab6c05cb-eaf9-425b-92c5-11db579137cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.column-align-center > div.sort-wrapper > span.fi.icon-down-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>5a2dd5f3-b503-49bf-8da3-cec6e816edae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-down-dir icon-list</value>
      <webElementGuid>d627879c-db89-41ad-b980-8f44a096ab63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell width-200px-f cursor-pointer-f cdk-column-group-name mat-column-group-name ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-down-dir icon-list&quot;]</value>
      <webElementGuid>9c871c86-e861-403a-ae2a-34bc56af8a55</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/span[2]</value>
      <webElementGuid>960b6496-53cd-4260-a169-0c53ffd108fa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
