<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Last Activity_fi icon-down-dir icon-list</name>
   <tag></tag>
   <elementGuidId>fdf8b718-1bbb-4b89-94b8-ebf3b5aa05dd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>th.mat-header-cell.cdk-header-cell.width-150px-f.cursor-pointer-f.cdk-column-updatedAt.mat-column-updatedAt.ng-star-inserted > div.column-align-center > div.sort-wrapper > span.fi.icon-down-dir.icon-list</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//th[5]/div/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>30b2c697-a6b8-429b-abfe-97abeba82ab7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fi icon-down-dir icon-list</value>
      <webElementGuid>9040853b-4bb5-45b6-bf14-edfca7ee9b8b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/thead[1]/tr[@class=&quot;mat-header-row cdk-header-row ng-star-inserted&quot;]/th[@class=&quot;mat-header-cell cdk-header-cell width-150px-f cursor-pointer-f cdk-column-updatedAt mat-column-updatedAt ng-star-inserted&quot;]/div[@class=&quot;column-align-center&quot;]/div[@class=&quot;sort-wrapper&quot;]/span[@class=&quot;fi icon-down-dir icon-list&quot;]</value>
      <webElementGuid>8d707535-5f32-4f87-88d2-3d21ff4b4238</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[5]/div/div/span[2]</value>
      <webElementGuid>ee69806a-e2da-46df-9ded-972d91f00b15</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
