<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Audience Manager_header-item style-setti_563204</name>
   <tag></tag>
   <elementGuidId>205c0b3a-1be4-43d3-afe5-8c273810d8ba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.header-item.style-setting.header-desktop.header-item-hover.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>6bdfb121-2467-4305-b18c-8b8ea6682317</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-item style-setting header-desktop header-item-hover ng-star-inserted</value>
      <webElementGuid>353ffee1-09c8-412b-862e-83cee1cfe6af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/li[@class=&quot;header-item style-setting header-desktop header-item-hover ng-star-inserted&quot;]</value>
      <webElementGuid>6f1051ef-2f0d-4d7b-b0a7-df57dc315cc9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::li[1]</value>
      <webElementGuid>31de5f89-2637-46dd-a979-e92d123fc010</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::li[1]</value>
      <webElementGuid>a644f450-0e4f-4356-af04-fd3051911234</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='F'])[1]/preceding::li[4]</value>
      <webElementGuid>7d0e2518-d104-4768-9827-21a71c8b6557</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='fauzan'])[1]/preceding::li[4]</value>
      <webElementGuid>345d1e7c-8761-404b-ae83-e9541c7a2706</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li</value>
      <webElementGuid>049019fe-d8a8-4708-9008-6d65440dc21a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
