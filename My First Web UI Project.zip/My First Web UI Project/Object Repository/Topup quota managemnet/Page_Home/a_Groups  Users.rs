<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Groups  Users</name>
   <tag></tag>
   <elementGuidId>b4b683e2-4d6e-4d9e-ad78-ad4d5d9be2c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.item-setting.ng-star-inserted</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Groups &amp; Users')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4549c1da-15f1-497a-ba64-ddf1bdb11187</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/casc2nd/user/group-list</value>
      <webElementGuid>a0d08047-6732-43a9-ac19-9cddc7463e67</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-setting ng-star-inserted</value>
      <webElementGuid>45bbce01-7901-436f-b83e-f8d508298ca0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Groups &amp; Users</value>
      <webElementGuid>e00a4482-1e0c-4879-819f-0ef4f222f41a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/ul[@class=&quot;setting-dropdown header-desktop ng-star-inserted&quot;]/a[@class=&quot;item-setting ng-star-inserted&quot;]</value>
      <webElementGuid>e64e69fc-4d0f-46f4-a721-17df14757e0b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Groups &amp; Users')]</value>
      <webElementGuid>15079699-5a33-4106-91d4-38aa4fa04b24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::a[1]</value>
      <webElementGuid>737a563d-e076-4640-a5cc-e4c40787ebc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[1]/following::a[1]</value>
      <webElementGuid>a2b8c2bb-41c1-45d4-af26-614c92fbf1c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quota Management'])[1]/preceding::a[1]</value>
      <webElementGuid>8a664297-df0f-470c-a065-b2b080de616b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Request'])[1]/preceding::a[2]</value>
      <webElementGuid>929af0cc-20d9-4e31-97a8-a9d308220bb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Groups &amp; Users']/parent::*</value>
      <webElementGuid>c772e757-78c4-42e7-afb2-995d27625aca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/casc2nd/user/group-list')]</value>
      <webElementGuid>97e8fe59-d619-4f22-923f-e53ac1170577</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul/a</value>
      <webElementGuid>f82c36bc-9e16-45b0-b431-e62616927536</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/casc2nd/user/group-list' and (text() = ' Groups &amp; Users' or . = ' Groups &amp; Users')]</value>
      <webElementGuid>dbfbf6e1-9f3a-4fec-b2a9-af15c50c7e8d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
