<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Quota Management</name>
   <tag></tag>
   <elementGuidId>bc3f719d-659d-4f21-bc5a-e43b27f211eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Quota Management')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>06c6027d-a4a0-4f65-863e-8e6b2f2ec026</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/casc2nd/sync/quotaManagement</value>
      <webElementGuid>6f332a4f-1e6a-4a76-95fc-770e697941b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-setting ng-star-inserted</value>
      <webElementGuid>bddf3e29-a655-4ed5-ab2c-9d857e96120b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Quota Management</value>
      <webElementGuid>1fce8af0-65dc-4c02-a9c2-8b1bd0ffadfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-header[1]/ul[@class=&quot;body-header&quot;]/ul[@class=&quot;setting-dropdown header-desktop ng-star-inserted&quot;]/a[@class=&quot;item-setting ng-star-inserted&quot;]</value>
      <webElementGuid>db8d5c51-eb76-479e-a2ea-7da4570bc6cc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Quota Management')]</value>
      <webElementGuid>28036900-d786-4f5d-8183-3127665c0d7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Groups &amp; Users'])[1]/following::a[1]</value>
      <webElementGuid>eb803e75-89f3-49f2-a766-3e668237f9b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audience Manager'])[2]/following::a[2]</value>
      <webElementGuid>f7a28ffe-637e-4ad5-a132-9b8c3f5bfff1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download Request'])[1]/preceding::a[1]</value>
      <webElementGuid>6ed94eb5-0600-40da-b280-6d4a3155ed1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refresh Scheduler'])[1]/preceding::a[2]</value>
      <webElementGuid>cadea96e-8694-4eba-a294-745574e74c50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Quota Management']/parent::*</value>
      <webElementGuid>8081976d-212c-4a0c-928f-3f6b49caed0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/casc2nd/sync/quotaManagement')]</value>
      <webElementGuid>dba99d69-73df-4c7f-a84a-a7ce91542a85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul/a[2]</value>
      <webElementGuid>283ebecd-c53a-4772-9a10-37757f513b57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/casc2nd/sync/quotaManagement' and (text() = ' Quota Management' or . = ' Quota Management')]</value>
      <webElementGuid>88e2bdfc-c708-4eaf-8175-53048d61dc8e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
