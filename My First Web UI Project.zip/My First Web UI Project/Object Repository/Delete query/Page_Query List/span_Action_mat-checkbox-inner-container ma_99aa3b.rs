<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Action_mat-checkbox-inner-container ma_99aa3b</name>
   <tag></tag>
   <elementGuidId>65e535e7-1b40-424f-9fc7-4d64e90920e7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mat-checkbox-2 > label.mat-checkbox-layout > span.mat-checkbox-inner-container.mat-checkbox-inner-container-no-side-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-checkbox[@id='mat-checkbox-2']/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>0bce6969-73b6-4f1e-93de-cf43ec591244</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin</value>
      <webElementGuid>ba919def-d6b0-48ce-b34e-dd6b52a206cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-checkbox-2&quot;)/label[@class=&quot;mat-checkbox-layout&quot;]/span[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;]</value>
      <webElementGuid>37625785-0170-4e84-97f5-cc2d4e53dce3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-checkbox[@id='mat-checkbox-2']/label/span</value>
      <webElementGuid>e5c2b558-2c8e-46d6-8ae0-5f31f2c401bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/following::span[1]</value>
      <webElementGuid>d1f8ab31-f933-4b24-9d58-8214a495830c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last Refresh'])[1]/following::span[2]</value>
      <webElementGuid>e16db94b-8ebe-406d-81f6-b47b8e1c7c04</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Test katalon'])[1]/preceding::span[8]</value>
      <webElementGuid>672e40f7-c0b0-4381-a245-e39c1b8e2801</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Query ID: 801'])[1]/preceding::span[9]</value>
      <webElementGuid>c0aaa3c1-9ad9-49ef-ad5f-325ff176671d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/mat-checkbox/label/span</value>
      <webElementGuid>192f526f-8b59-48a9-a12a-cb0f968c2b21</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
