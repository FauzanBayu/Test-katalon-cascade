<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Action_mat-checkbox-inner-container ma_99aa3b</name>
   <tag></tag>
   <elementGuidId>d8eda565-609e-4cb3-8f32-3c027726006c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mat-checkbox-8 > label.mat-checkbox-layout > span.mat-checkbox-inner-container.mat-checkbox-inner-container-no-side-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-checkbox[@id='mat-checkbox-8']/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>62a37ec9-794f-48df-9e79-59e3be4586ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin</value>
      <webElementGuid>e7889ebb-9f89-4073-94b9-8ad0a8ff5c4b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-checkbox-8&quot;)/label[@class=&quot;mat-checkbox-layout&quot;]/span[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;]</value>
      <webElementGuid>919bbd46-3c82-4928-a7bd-c4a026f73901</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-checkbox[@id='mat-checkbox-8']/label/span</value>
      <webElementGuid>1449659d-5db1-464e-9a19-f5114ea99b27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/following::span[1]</value>
      <webElementGuid>28aafdcb-4266-4726-8591-5377551afcb3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[1]/following::span[4]</value>
      <webElementGuid>9c8030d4-cab6-43ae-a812-cf242bd80aa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='new clone'])[1]/preceding::span[8]</value>
      <webElementGuid>83f2f97c-7814-4354-b89d-30bcbe8eed60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz ID: 206'])[1]/preceding::span[9]</value>
      <webElementGuid>7b0afbef-95d4-4fce-adc0-44fccb4866d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/mat-checkbox/label/span</value>
      <webElementGuid>dcebade5-5bff-4959-838f-bdd0a3811c28</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
