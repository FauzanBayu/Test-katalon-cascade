<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Delete Completely</name>
   <tag></tag>
   <elementGuidId>2f3c1c4b-c043-4189-9a96-e6a3bf090d18</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Clone'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>00c1fbe1-1d51-4336-9071-fda75a9ae87e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>more-selection sub-text</value>
      <webElementGuid>9d54e3c1-836a-4899-b5be-b849e9b0f221</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Delete Completely</value>
      <webElementGuid>af529566-b21a-48e7-803d-4716002d7ab0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/table[@class=&quot;mat-table cdk-table table-global margin-top-20px-f&quot;]/tbody[1]/tr[@class=&quot;mat-row cdk-row cursor-pointer-f ng-star-inserted&quot;]/td[@class=&quot;mat-cell cdk-cell cdk-column-more mat-column-more ng-star-inserted&quot;]/div[@class=&quot;column-align-center position-relative-f ng-star-inserted&quot;]/div[@class=&quot;more-outer ng-star-inserted&quot;]/div[@class=&quot;more-selection sub-text&quot;]</value>
      <webElementGuid>f67fce7b-f0a6-4425-ab43-c744f4d3cc13</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clone'])[1]/following::div[1]</value>
      <webElementGuid>58d53977-51de-4e09-a079-0e1f5fd31b38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publish'])[1]/following::div[2]</value>
      <webElementGuid>9d27a917-ade4-47e2-bb74-8397a8f16db0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='new clone'])[2]/preceding::div[1]</value>
      <webElementGuid>283a5461-6f2d-49e4-92c9-0f49e20650c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Viz ID: 205'])[1]/preceding::div[1]</value>
      <webElementGuid>6cbcc3a1-9d34-4844-a752-3d8433c16f92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Delete Completely']/parent::*</value>
      <webElementGuid>94ee6885-2e45-4929-a98c-724451b0d1ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[7]/div/div/div[3]</value>
      <webElementGuid>488d7428-a1e1-42f6-8d7a-3379ed6331ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Delete Completely' or . = 'Delete Completely')]</value>
      <webElementGuid>fa876d20-14f9-41d6-ae33-03b52f7746e2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
