<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Remove</name>
   <tag></tag>
   <elementGuidId>507d6b82-3531-442f-8533-3a9b8f685a52</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.btn-global.type-contained.size-standart.float-right-f.margin-left-20px-f</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[5]/following::button[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>d2dac788-9314-435e-a84c-c895b5688ded</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-global type-contained size-standart float-right-f margin-left-20px-f</value>
      <webElementGuid>53e31663-0148-4d20-a70c-e769e2fcbe7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Remove </value>
      <webElementGuid>7906fe85-1a78-4c5e-9c14-afdbf80613c0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/app-default[@class=&quot;ng-star-inserted&quot;]/mat-drawer-container[@class=&quot;mat-drawer-container example-container mat-typography outer-not-expand&quot;]/mat-drawer-content[@class=&quot;mat-drawer-content ng-star-inserted&quot;]/app-product-list[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;body-content&quot;]/div[@class=&quot;querylist-footer-table margin-top-20px-f ng-star-inserted&quot;]/div[@class=&quot;querylist-header-table-right ng-star-inserted&quot;]/button[@class=&quot;btn-global type-contained size-standart float-right-f margin-left-20px-f&quot;]</value>
      <webElementGuid>268bc4a2-34c3-4f04-8cfd-e3540faf6213</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Unpublished'])[5]/following::button[4]</value>
      <webElementGuid>34107e0b-46bf-4ac8-a219-cb3875d587a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='aditadmin@salt.co.id'])[1]/following::button[4]</value>
      <webElementGuid>8453acba-d472-4363-aa53-c3db54c643ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/preceding::button[1]</value>
      <webElementGuid>56a6b6de-ddf1-4728-ba8e-8b2b00d36eb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='WMS help you to generate image tiles from geospatial data. WMS can only use Kinetica datasource.'])[1]/preceding::button[2]</value>
      <webElementGuid>a529575c-1952-4a79-bb34-2e9b8fa82b9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Remove']/parent::*</value>
      <webElementGuid>6c3f74e2-3edb-43d5-902e-db755ae8fd98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/button</value>
      <webElementGuid>2badb922-5326-4223-8210-3d269b2f424c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = ' Remove ' or . = ' Remove ')]</value>
      <webElementGuid>52bf2546-45bf-4ad6-b7e8-51d566bb0ae9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
