<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Action_mat-checkbox-inner-container ma_99aa3b</name>
   <tag></tag>
   <elementGuidId>30be8976-faf6-4176-b835-fccfda3a1aa9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#mat-checkbox-2 > label.mat-checkbox-layout > span.mat-checkbox-inner-container.mat-checkbox-inner-container-no-side-margin</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//mat-checkbox[@id='mat-checkbox-2']/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>5f34085c-40dc-4a96-b0c0-660d8b19e3b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin</value>
      <webElementGuid>334fbb89-a278-4f81-8faa-bf02b2376941</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mat-checkbox-2&quot;)/label[@class=&quot;mat-checkbox-layout&quot;]/span[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;]</value>
      <webElementGuid>317fa441-50f8-401c-954f-cedb52b3b1cf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//mat-checkbox[@id='mat-checkbox-2']/label/span</value>
      <webElementGuid>3795c136-bc0f-4b22-b9fa-035e59495ba0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/following::span[1]</value>
      <webElementGuid>de19ecb1-ae46-41e6-a0aa-02abfbe2e102</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Status'])[1]/following::span[4]</value>
      <webElementGuid>666ffdbb-5440-401e-b453-2bab5c864b3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='dashboard katalon - copy - copy'])[1]/preceding::span[8]</value>
      <webElementGuid>08ce2e19-f118-4f90-a6bf-abc05d5b7719</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard ID: 44'])[1]/preceding::span[9]</value>
      <webElementGuid>3f0c976e-c2d3-4a81-b66b-e374707995d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/mat-checkbox/label/span</value>
      <webElementGuid>4afa693a-4b95-4cfa-91a0-e48b28db30c7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
