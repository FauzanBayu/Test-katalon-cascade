import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://10.59.106.122/casc2nd/auth/login')

WebUI.setText(findTestObject('Object Repository/Clone query/Page_Login/input_Forgot_field-global type-field-for-lo_a1db2b'), 
    'fauzan')

WebUI.setEncryptedText(findTestObject('Object Repository/Clone query/Page_Login/input_Forgot_field-global type-field-for-lo_2afd9e'), 
    'QTlAVMjKOXOjh9q/xBjuew==')

WebUI.click(findTestObject('Object Repository/Clone query/Page_Login/button_Login'))

WebUI.click(findTestObject('Object Repository/Clone query/Page_Home/span_Dashboard_mat-list-icon fin icon-query'))

WebUI.click(findTestObject('Object Repository/Clone query/Page_Query List/span_-_fi fi icon-dot-3 font-size-18px-f'))

WebUI.click(findTestObject('Object Repository/Clone query/Page_Query List/div_Clone'))

WebUI.setText(findTestObject('Object Repository/Clone query/Page_Query List/input_Clone Query_field-global type-standar_fa6407'), 
    'test katalon copynew')

WebUI.click(findTestObject('Object Repository/Clone query/Page_Query List/div_Select Group'))

WebUI.click(findTestObject('Object Repository/Clone query/Page_Query List/div_operational'))

WebUI.click(findTestObject('Object Repository/Clone query/Page_Query List/div_Select Datasource'))

WebUI.click(findTestObject('Object Repository/Clone query/Page_Query List/div_localhost'))

WebUI.click(findTestObject('Object Repository/Clone query/Page_Query List/button_Clone'))

WebUI.closeBrowser()

